/*   1:    */package com.radius.server.attribute;
/*   2:    */
/*   3:    */import com.radius.server.dictionary.AttributeType;
/*   4:    */import com.radius.server.dictionary.DefaultDictionary;
/*   5:    */import com.radius.server.dictionary.Dictionary;
/*   6:    */import com.radius.server.util.RadiusException;
/*   7:    */import com.radius.server.util.RadiusUtil;
/*   8:    */
/*  29:    */public class RadiusAttribute
/*  30:    */{
/*  31:    */  public RadiusAttribute() {}
/*  32:    */  
/*  33:    */  public RadiusAttribute(int type, byte[] data)
/*  34:    */  {
/*  35: 35 */    setAttributeType(type);
/*  36: 36 */    setAttributeData(data);
/*  37:    */  }
/*  38:    */  
/*  42:    */  public byte[] getAttributeData()
/*  43:    */  {
/*  44: 44 */    return this.attributeData;
/*  45:    */  }
/*  46:    */  
/*  50:    */  public void setAttributeData(byte[] attributeData)
/*  51:    */  {
/*  52: 52 */    if (attributeData == null)
/*  53: 53 */      throw new NullPointerException("attribute data is null");
/*  54: 54 */    this.attributeData = attributeData;
/*  55:    */  }
/*  56:    */  
/*  60:    */  public int getAttributeType()
/*  61:    */  {
/*  62: 62 */    return this.attributeType;
/*  63:    */  }
/*  64:    */  
/*  68:    */  public void setAttributeType(int attributeType)
/*  69:    */  {
/*  70: 70 */    if ((attributeType < 0) || (attributeType > 255))
/*  71: 71 */      throw new IllegalArgumentException("attribute type invalid: " + attributeType);
/*  72: 72 */    this.attributeType = attributeType;
/*  73:    */  }
/*  74:    */  
/*  78:    */  public void setAttributeValue(String value)
/*  79:    */  {
/*  80: 80 */    throw new RuntimeException("cannot set the value of attribute " + this.attributeType + " as a string");
/*  81:    */  }
/*  82:    */  
/*  87:    */  public String getAttributeValue()
/*  88:    */  {
/*  89: 89 */    return RadiusUtil.getHexString(getAttributeData());
/*  90:    */  }
/*  91:    */  
/*  97:    */  public int getVendorId()
/*  98:    */  {
/*  99: 99 */    return this.vendorId;
/* 100:    */  }
/* 101:    */  
/* 107:    */  public void setVendorId(int vendorId)
/* 108:    */  {
/* 109:109 */    this.vendorId = vendorId;
/* 110:    */  }
/* 111:    */  
/* 115:    */  public Dictionary getDictionary()
/* 116:    */  {
/* 117:117 */    return this.dictionary;
/* 118:    */  }
/* 119:    */  
/* 125:    */  public void setDictionary(Dictionary dictionary)
/* 126:    */  {
/* 127:127 */    this.dictionary = dictionary;
/* 128:    */  }
/* 129:    */  
/* 133:    */  public byte[] writeAttribute()
/* 134:    */  {
/* 135:135 */    if (getAttributeType() == -1)
/* 136:136 */      throw new IllegalArgumentException("attribute type not set");
/* 137:137 */    if (this.attributeData == null) {
/* 138:138 */      throw new NullPointerException("attribute data not set");
/* 139:    */    }
/* 140:140 */    byte[] attr = new byte[2 + this.attributeData.length];
/* 141:141 */    attr[0] = ((byte)getAttributeType());
/* 142:142 */    attr[1] = ((byte)(2 + this.attributeData.length));
/* 143:143 */    System.arraycopy(this.attributeData, 0, attr, 2, this.attributeData.length);
/* 144:144 */    return attr;
/* 145:    */  }
/* 146:    */  
/* 150:    */  public void readAttribute(byte[] data, int offset, int length)
/* 151:    */    throws RadiusException
/* 152:    */  {
/* 153:153 */    if (length < 2)
/* 154:154 */      throw new RadiusException("attribute length too small: " + length);
/* 155:155 */    int attrType = data[offset] & 0xFF;
/* 156:156 */    int attrLen = data[(offset + 1)] & 0xFF;
/* 157:157 */    byte[] attrData = new byte[attrLen - 2];
/* 158:158 */    System.arraycopy(data, offset + 2, attrData, 0, attrLen - 2);
/* 159:159 */    setAttributeType(attrType);
/* 160:160 */    setAttributeData(attrData);
/* 161:    */  }
/* 162:    */  
/* 169:    */  public String toString()
/* 170:    */  {
/* 171:171 */    AttributeType at = getAttributeTypeObject();
/* 172:172 */    String name; String name; if (at != null) {
/* 173:173 */      name = at.getName(); } else { String name;
/* 174:174 */      if (getVendorId() != -1) {
/* 175:175 */        name = "Unknown-Sub-Attribute-" + getAttributeType();
/* 176:    */      } else {
/* 177:177 */        name = "Unknown-Attribute-" + getAttributeType();
/* 178:    */      }
/* 179:    */    }
/* 180:180 */    if (getVendorId() != -1) {
/* 181:181 */      name = "  " + name;
/* 182:    */    }
/* 183:183 */    return name + ": " + getAttributeValue();
/* 184:    */  }
/* 185:    */  
/* 189:    */  public AttributeType getAttributeTypeObject()
/* 190:    */  {
/* 191:191 */    if (getVendorId() != -1) {
/* 192:192 */      return this.dictionary.getAttributeTypeByCode(getVendorId(), getAttributeType());
/* 193:    */    }
/* 194:194 */    return this.dictionary.getAttributeTypeByCode(getAttributeType());
/* 195:    */  }
/* 196:    */  
/* 203:    */  public static RadiusAttribute createRadiusAttribute(Dictionary dictionary, int vendorId, int attributeType)
/* 204:    */  {
/* 205:205 */    RadiusAttribute attribute = new RadiusAttribute();
/* 206:    */    
/* 207:207 */    AttributeType at = dictionary.getAttributeTypeByCode(vendorId, attributeType);
/* 208:208 */    if ((at != null) && (at.getAttributeClass() != null)) {
/* 209:    */      try {
/* 210:210 */        attribute = (RadiusAttribute)at.getAttributeClass().newInstance();
/* 211:    */      }
/* 212:    */      catch (Exception localException) {}
/* 213:    */    }
/* 214:    */    
/* 216:216 */    attribute.setAttributeType(attributeType);
/* 217:217 */    attribute.setDictionary(dictionary);
/* 218:218 */    attribute.setVendorId(vendorId);
/* 219:219 */    return attribute;
/* 220:    */  }
/* 221:    */  
/* 228:    */  public static RadiusAttribute createRadiusAttribute(int vendorId, int attributeType)
/* 229:    */  {
/* 230:230 */    Dictionary dictionary = DefaultDictionary.getDefaultDictionary();
/* 231:231 */    return createRadiusAttribute(dictionary, vendorId, attributeType);
/* 232:    */  }
/* 233:    */  
/* 239:    */  public static RadiusAttribute createRadiusAttribute(int attributeType)
/* 240:    */  {
/* 241:241 */    Dictionary dictionary = DefaultDictionary.getDefaultDictionary();
/* 242:242 */    return createRadiusAttribute(dictionary, -1, attributeType);
/* 243:    */  }
/* 244:    */  
/* 248:248 */  private Dictionary dictionary = DefaultDictionary.getDefaultDictionary();
/* 249:    */  
/* 253:253 */  private int attributeType = -1;
/* 254:    */  
/* 258:258 */  private int vendorId = -1;
/* 259:    */  
/* 263:263 */  private byte[] attributeData = null;
/* 264:    */}


/* Location:           D:\cache\windows\Desktop\radius-server-1.0\
 * Qualified Name:     com.radius.server.attribute.RadiusAttribute
 * JD-Core Version:    0.7.0-SNAPSHOT-20130630
 */