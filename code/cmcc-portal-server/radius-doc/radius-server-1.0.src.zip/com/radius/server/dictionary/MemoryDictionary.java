/*   1:    */package com.radius.server.dictionary;
/*   2:    */
/*   3:    */import java.util.HashMap;
/*   4:    */import java.util.Iterator;
/*   5:    */import java.util.Map;
/*   6:    */import java.util.Map.Entry;
/*   7:    */import java.util.Set;
/*   8:    */
/*  29:    */public class MemoryDictionary
/*  30:    */  implements WritableDictionary
/*  31:    */{
/*  32:    */  public AttributeType getAttributeTypeByCode(int typeCode)
/*  33:    */  {
/*  34: 34 */    return getAttributeTypeByCode(-1, typeCode);
/*  35:    */  }
/*  36:    */  
/*  43:    */  public AttributeType getAttributeTypeByCode(int vendorCode, int typeCode)
/*  44:    */  {
/*  45: 45 */    Map<Integer, AttributeType> vendorAttributes = (Map)this.attributesByCode.get(new Integer(vendorCode));
/*  46: 46 */    if (vendorAttributes == null) {
/*  47: 47 */      return null;
/*  48:    */    }
/*  49: 49 */    return (AttributeType)vendorAttributes.get(new Integer(typeCode));
/*  50:    */  }
/*  51:    */  
/*  57:    */  public AttributeType getAttributeTypeByName(String typeName)
/*  58:    */  {
/*  59: 59 */    return (AttributeType)this.attributesByName.get(typeName);
/*  60:    */  }
/*  61:    */  
/*  68:    */  public int getVendorId(String vendorName)
/*  69:    */  {
/*  70: 70 */    for (Iterator<Map.Entry<Integer, String>> i = this.vendorsByCode.entrySet().iterator(); i.hasNext();) {
/*  71: 71 */      Map.Entry<Integer, String> e = (Map.Entry)i.next();
/*  72: 72 */      if (((String)e.getValue()).equals(vendorName))
/*  73: 73 */        return ((Integer)e.getKey()).intValue();
/*  74:    */    }
/*  75: 75 */    return -1;
/*  76:    */  }
/*  77:    */  
/*  84:    */  public String getVendorName(int vendorId)
/*  85:    */  {
/*  86: 86 */    return (String)this.vendorsByCode.get(new Integer(vendorId));
/*  87:    */  }
/*  88:    */  
/*  94:    */  public void addVendor(int vendorId, String vendorName)
/*  95:    */  {
/*  96: 96 */    if (vendorId < 0)
/*  97: 97 */      throw new IllegalArgumentException("vendor ID must be positive");
/*  98: 98 */    if (getVendorName(vendorId) != null)
/*  99: 99 */      throw new IllegalArgumentException("duplicate vendor code");
/* 100:100 */    if ((vendorName == null) || (vendorName.length() == 0))
/* 101:101 */      throw new IllegalArgumentException("vendor name empty");
/* 102:102 */    this.vendorsByCode.put(new Integer(vendorId), vendorName);
/* 103:    */  }
/* 104:    */  
/* 109:    */  public void addAttributeType(AttributeType attributeType)
/* 110:    */  {
/* 111:111 */    if (attributeType == null) {
/* 112:112 */      throw new IllegalArgumentException("attribute type must not be null");
/* 113:    */    }
/* 114:114 */    Integer vendorId = new Integer(attributeType.getVendorId());
/* 115:115 */    Integer typeCode = new Integer(attributeType.getTypeCode());
/* 116:116 */    String attributeName = attributeType.getName();
/* 117:    */    
/* 118:118 */    if (this.attributesByName.containsKey(attributeName)) {
/* 119:119 */      throw new IllegalArgumentException("duplicate attribute name: " + attributeName);
/* 120:    */    }
/* 121:121 */    Map<Integer, AttributeType> vendorAttributes = (Map)this.attributesByCode.get(vendorId);
/* 122:122 */    if (vendorAttributes == null) {
/* 123:123 */      vendorAttributes = new HashMap();
/* 124:124 */      this.attributesByCode.put(vendorId, vendorAttributes);
/* 125:    */    }
/* 126:126 */    if (vendorAttributes.containsKey(typeCode)) {
/* 127:127 */      throw new IllegalArgumentException("duplicate type code: " + typeCode);
/* 128:    */    }
/* 129:129 */    this.attributesByName.put(attributeName, attributeType);
/* 130:130 */    vendorAttributes.put(typeCode, attributeType);
/* 131:    */  }
/* 132:    */  
/* 133:133 */  private Map<Integer, String> vendorsByCode = new HashMap();
/* 134:134 */  private Map<Integer, Map<Integer, AttributeType>> attributesByCode = new HashMap();
/* 135:135 */  private Map<String, AttributeType> attributesByName = new HashMap();
/* 136:    */}


/* Location:           D:\cache\windows\Desktop\radius-server-1.0\
 * Qualified Name:     com.radius.server.dictionary.MemoryDictionary
 * JD-Core Version:    0.7.0-SNAPSHOT-20130630
 */