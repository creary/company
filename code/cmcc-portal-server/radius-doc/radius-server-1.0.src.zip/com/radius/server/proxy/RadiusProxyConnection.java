/*  1:   */package com.radius.server.proxy;
/*  2:   */
/*  3:   */import com.radius.server.packet.RadiusPacket;
/*  4:   */import com.radius.server.util.RadiusEndpoint;
/*  5:   */
/* 18:   */public class RadiusProxyConnection
/* 19:   */{
/* 20:   */  private RadiusEndpoint radiusServer;
/* 21:   */  private RadiusEndpoint radiusClient;
/* 22:   */  private int port;
/* 23:   */  private RadiusPacket packet;
/* 24:   */  
/* 25:   */  public RadiusProxyConnection(RadiusEndpoint radiusServer, RadiusEndpoint radiusClient, RadiusPacket packet, int port)
/* 26:   */  {
/* 27:27 */    this.radiusServer = radiusServer;
/* 28:28 */    this.radiusClient = radiusClient;
/* 29:29 */    this.packet = packet;
/* 30:30 */    this.port = port;
/* 31:   */  }
/* 32:   */  
/* 36:   */  public RadiusEndpoint getRadiusClient()
/* 37:   */  {
/* 38:38 */    return this.radiusClient;
/* 39:   */  }
/* 40:   */  
/* 44:   */  public RadiusEndpoint getRadiusServer()
/* 45:   */  {
/* 46:46 */    return this.radiusServer;
/* 47:   */  }
/* 48:   */  
/* 52:   */  public RadiusPacket getPacket()
/* 53:   */  {
/* 54:54 */    return this.packet;
/* 55:   */  }
/* 56:   */  
/* 61:   */  public int getPort()
/* 62:   */  {
/* 63:63 */    return this.port;
/* 64:   */  }
/* 65:   */}


/* Location:           D:\cache\windows\Desktop\radius-server-1.0\
 * Qualified Name:     com.radius.server.proxy.RadiusProxyConnection
 * JD-Core Version:    0.7.0-SNAPSHOT-20130630
 */