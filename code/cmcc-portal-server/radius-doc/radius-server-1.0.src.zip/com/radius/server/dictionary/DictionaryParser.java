/*   1:    */package com.radius.server.dictionary;
/*   2:    */
/*   3:    */import com.radius.server.attribute.IntegerAttribute;
/*   4:    */import com.radius.server.attribute.IpAttribute;
/*   5:    */import com.radius.server.attribute.RadiusAttribute;
/*   6:    */import com.radius.server.attribute.StringAttribute;
/*   7:    */import com.radius.server.attribute.VendorSpecificAttribute;
/*   8:    */import java.io.BufferedReader;
/*   9:    */import java.io.File;
/*  10:    */import java.io.FileInputStream;
/*  11:    */import java.io.IOException;
/*  12:    */import java.io.InputStream;
/*  13:    */import java.io.InputStreamReader;
/*  14:    */import java.util.StringTokenizer;
/*  15:    */import org.apache.log4j.Logger;
/*  16:    */
/*  29:    */public class DictionaryParser
/*  30:    */{
/*  31: 31 */  static final Logger logger = Logger.getLogger(DictionaryParser.class);
/*  32:    */  
/*  39:    */  public static Dictionary parseDictionary(String filepath, InputStream source)
/*  40:    */    throws IOException
/*  41:    */  {
/*  42: 42 */    WritableDictionary d = new MemoryDictionary();
/*  43: 43 */    parseDictionary(filepath, source, d);
/*  44: 44 */    return d;
/*  45:    */  }
/*  46:    */  
/*  54:    */  public static void parseDictionary(String filepath, InputStream source, WritableDictionary dictionary)
/*  55:    */    throws IOException
/*  56:    */  {
/*  57: 57 */    BufferedReader in = new BufferedReader(new InputStreamReader(source));
/*  58:    */    
/*  60: 60 */    int lineNum = -1;
/*  61: 61 */    String line; while ((line = in.readLine()) != null)
/*  62:    */    {
/*  63: 63 */      lineNum++;
/*  64: 64 */      String line = line.trim();
/*  65: 65 */      if ((!line.startsWith("#")) && (line.length() != 0))
/*  66:    */      {
/*  69: 69 */        StringTokenizer tok = new StringTokenizer(line);
/*  70: 70 */        if (tok.hasMoreTokens())
/*  71:    */        {
/*  73: 73 */          String lineType = tok.nextToken().trim();
/*  74: 74 */          if (lineType.equalsIgnoreCase("ATTRIBUTE")) {
/*  75: 75 */            parseAttributeLine(dictionary, tok, lineNum);
/*  76: 76 */          } else if (lineType.equalsIgnoreCase("VALUE")) {
/*  77: 77 */            parseValueLine(dictionary, tok, lineNum);
/*  78: 78 */          } else if (lineType.equalsIgnoreCase("$INCLUDE")) {
/*  79: 79 */            includeDictionaryFile(filepath, dictionary, tok, lineNum);
/*  80: 80 */          } else if (lineType.equalsIgnoreCase("VENDORATTR")) {
/*  81: 81 */            parseVendorAttributeLine(dictionary, tok, lineNum);
/*  82: 82 */          } else if (lineType.equals("VENDOR")) {
/*  83: 83 */            parseVendorLine(dictionary, tok, lineNum);
/*  84: 84 */          } else if (lineType.equals("BEGIN-VENDOR")) {
/*  85: 85 */            parseBeginVendor(dictionary, tok, lineNum);
/*  86: 86 */          } else if (lineType.equals("END-VENDOR")) {
/*  87: 87 */            parseEndVendor(dictionary, tok, lineNum);
/*  88:    */          } else
/*  89: 89 */            throw new IOException("unknown line type: " + lineType + " line: " + lineNum);
/*  90:    */        }
/*  91:    */      }
/*  92:    */    }
/*  93:    */  }
/*  94:    */  
/*  95: 95 */  private static void parseBeginVendor(WritableDictionary dictionary, StringTokenizer tok, int lineNum) throws IOException { if (tok.countTokens() != 1) {
/*  96: 96 */      throw new IOException("syntax error on line " + lineNum);
/*  97:    */    }
/*  98: 98 */    String token1 = tok.nextToken().trim();
/*  99:    */    
/* 100:100 */    logger.info("BeginVendor: " + token1);
/* 101:    */  }
/* 102:    */  
/* 103:    */  private static void parseEndVendor(WritableDictionary dictionary, StringTokenizer tok, int lineNum) throws IOException
/* 104:    */  {
/* 105:105 */    if (tok.countTokens() != 1) {
/* 106:106 */      throw new IOException("syntax error on line " + lineNum);
/* 107:    */    }
/* 108:108 */    String token1 = tok.nextToken().trim();
/* 109:    */    
/* 110:110 */    logger.info("EndVendor: " + token1);
/* 111:    */  }
/* 112:    */  
/* 115:    */  private static void parseAttributeLine(WritableDictionary dictionary, StringTokenizer tok, int lineNum)
/* 116:    */    throws IOException
/* 117:    */  {
/* 118:118 */    if (tok.countTokens() != 3) {
/* 119:119 */      throw new IOException("syntax error on line " + lineNum);
/* 120:    */    }
/* 121:    */    
/* 122:122 */    String name = tok.nextToken().trim();
/* 123:123 */    int code = Integer.parseInt(tok.nextToken());
/* 124:124 */    String typeStr = tok.nextToken().trim();
/* 125:    */    
/* 126:    */    Class<?> type;
/* 127:    */    Class<?> type;
/* 128:128 */    if (code == 26) {
/* 129:129 */      type = VendorSpecificAttribute.class;
/* 130:    */    } else {
/* 131:131 */      type = getAttributeTypeClass(code, typeStr);
/* 132:    */    }
/* 133:    */    
/* 134:134 */    dictionary.addAttributeType(new AttributeType(code, name, type));
/* 135:    */  }
/* 136:    */  
/* 139:    */  private static void parseValueLine(WritableDictionary dictionary, StringTokenizer tok, int lineNum)
/* 140:    */    throws IOException
/* 141:    */  {
/* 142:142 */    if (tok.countTokens() != 3) {
/* 143:143 */      throw new IOException("syntax error on line " + lineNum);
/* 144:    */    }
/* 145:145 */    String typeName = tok.nextToken().trim();
/* 146:146 */    String enumName = tok.nextToken().trim();
/* 147:147 */    String valStr = tok.nextToken().trim();
/* 148:    */    
/* 149:149 */    AttributeType at = dictionary.getAttributeTypeByName(typeName);
/* 150:150 */    if (at == null) {
/* 151:151 */      throw new IOException("unknown attribute type: " + typeName + ", line: " + lineNum);
/* 152:    */    }
/* 153:153 */    at.addEnumerationValue(Integer.parseInt(valStr), enumName);
/* 154:    */  }
/* 155:    */  
/* 158:    */  private static void parseVendorAttributeLine(WritableDictionary dictionary, StringTokenizer tok, int lineNum)
/* 159:    */    throws IOException
/* 160:    */  {
/* 161:161 */    if (tok.countTokens() != 4) {
/* 162:162 */      throw new IOException("syntax error on line " + lineNum);
/* 163:    */    }
/* 164:164 */    String vendor = tok.nextToken().trim();
/* 165:165 */    String name = tok.nextToken().trim();
/* 166:166 */    int code = Integer.parseInt(tok.nextToken().trim());
/* 167:167 */    String typeStr = tok.nextToken().trim();
/* 168:    */    
/* 169:169 */    Class<?> type = getAttributeTypeClass(code, typeStr);
/* 170:170 */    AttributeType at = new AttributeType(Integer.parseInt(vendor), code, name, type);
/* 171:171 */    dictionary.addAttributeType(at);
/* 172:    */  }
/* 173:    */  
/* 176:    */  private static void parseVendorLine(WritableDictionary dictionary, StringTokenizer tok, int lineNum)
/* 177:    */    throws IOException
/* 178:    */  {
/* 179:179 */    if (tok.countTokens() != 2) {
/* 180:180 */      throw new IOException("syntax error on line " + lineNum);
/* 181:    */    }
/* 182:182 */    String token1 = tok.nextToken().trim();
/* 183:183 */    String token2 = tok.nextToken().trim();
/* 184:    */    try
/* 185:    */    {
/* 186:186 */      int vendorId = Integer.parseInt(token1);
/* 187:187 */      String vendorName = token2.trim();
/* 188:    */      
/* 189:189 */      dictionary.addVendor(vendorId, vendorName);
/* 190:    */    } catch (Exception e) {
/* 191:191 */      String vendorName = token1;
/* 192:192 */      int vendorId = Integer.parseInt(token2);
/* 193:    */      
/* 194:194 */      dictionary.addVendor(vendorId, vendorName);
/* 195:    */    }
/* 196:    */  }
/* 197:    */  
/* 200:    */  private static void includeDictionaryFile(String filepath, WritableDictionary dictionary, StringTokenizer tok, int lineNum)
/* 201:    */    throws IOException
/* 202:    */  {
/* 203:203 */    if (tok.countTokens() != 1)
/* 204:204 */      throw new IOException("syntax error on line " + lineNum);
/* 205:205 */    String includeFile = tok.nextToken();
/* 206:    */    
/* 207:207 */    File incf = new File(includeFile);
/* 208:208 */    if (!incf.exists()) {
/* 209:209 */      String includeFilePath = filepath + File.separator + includeFile;
/* 210:210 */      incf = new File(includeFilePath);
/* 211:211 */      if (!incf.exists()) {
/* 212:212 */        throw new IOException("inclueded file '" + includeFile + "' not found, line " + lineNum);
/* 213:    */      }
/* 214:    */    }
/* 215:215 */    FileInputStream fis = new FileInputStream(incf);
/* 216:216 */    parseDictionary(filepath, fis, dictionary);
/* 217:    */  }
/* 218:    */  
/* 229:    */  private static Class<?> getAttributeTypeClass(int attributeType, String typeStr)
/* 230:    */  {
/* 231:231 */    Class<?> type = RadiusAttribute.class;
/* 232:232 */    if (typeStr.equalsIgnoreCase("string")) {
/* 233:233 */      type = StringAttribute.class;
/* 234:234 */    } else if (typeStr.equalsIgnoreCase("octets")) {
/* 235:235 */      type = RadiusAttribute.class;
/* 236:236 */    } else if ((typeStr.equalsIgnoreCase("integer")) || (typeStr.equalsIgnoreCase("date"))) {
/* 237:237 */      type = IntegerAttribute.class;
/* 238:238 */    } else if (typeStr.equalsIgnoreCase("ipaddr"))
/* 239:239 */      type = IpAttribute.class;
/* 240:240 */    return type;
/* 241:    */  }
/* 242:    */}


/* Location:           D:\cache\windows\Desktop\radius-server-1.0\
 * Qualified Name:     com.radius.server.dictionary.DictionaryParser
 * JD-Core Version:    0.7.0-SNAPSHOT-20130630
 */