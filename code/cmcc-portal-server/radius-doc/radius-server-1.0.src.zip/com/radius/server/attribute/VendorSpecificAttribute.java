/*   1:    */package com.radius.server.attribute;
/*   2:    */
/*   3:    */import com.radius.server.dictionary.AttributeType;
/*   4:    */import com.radius.server.dictionary.Dictionary;
/*   5:    */import com.radius.server.util.RadiusException;
/*   6:    */import java.io.ByteArrayOutputStream;
/*   7:    */import java.io.IOException;
/*   8:    */import java.util.ArrayList;
/*   9:    */import java.util.Iterator;
/*  10:    */import java.util.LinkedList;
/*  11:    */import java.util.List;
/*  12:    */
/*  34:    */public class VendorSpecificAttribute
/*  35:    */  extends RadiusAttribute
/*  36:    */{
/*  37:    */  public static final int VENDOR_SPECIFIC = 26;
/*  38:    */  
/*  39:    */  public VendorSpecificAttribute() {}
/*  40:    */  
/*  41:    */  public VendorSpecificAttribute(int vendorId)
/*  42:    */  {
/*  43: 43 */    setAttributeType(26);
/*  44: 44 */    setChildVendorId(vendorId);
/*  45:    */  }
/*  46:    */  
/*  50:    */  public void setChildVendorId(int childVendorId)
/*  51:    */  {
/*  52: 52 */    this.childVendorId = childVendorId;
/*  53:    */  }
/*  54:    */  
/*  58:    */  public int getChildVendorId()
/*  59:    */  {
/*  60: 60 */    return this.childVendorId;
/*  61:    */  }
/*  62:    */  
/*  67:    */  public void setDictionary(Dictionary dictionary)
/*  68:    */  {
/*  69: 69 */    super.setDictionary(dictionary);
/*  70: 70 */    for (Iterator<RadiusAttribute> i = this.subAttributes.iterator(); i.hasNext();) {
/*  71: 71 */      RadiusAttribute attr = (RadiusAttribute)i.next();
/*  72: 72 */      attr.setDictionary(dictionary);
/*  73:    */    }
/*  74:    */  }
/*  75:    */  
/*  79:    */  public void addSubAttribute(RadiusAttribute attribute)
/*  80:    */  {
/*  81: 81 */    if (attribute.getVendorId() != getChildVendorId()) {
/*  82: 82 */      throw new IllegalArgumentException(
/*  83: 83 */        "sub attribut has incorrect vendor ID");
/*  84:    */    }
/*  85: 85 */    this.subAttributes.add(attribute);
/*  86:    */  }
/*  87:    */  
/*  93:    */  public void addSubAttribute(String name, String value)
/*  94:    */  {
/*  95: 95 */    if ((name == null) || (name.length() == 0))
/*  96: 96 */      throw new IllegalArgumentException("type name is empty");
/*  97: 97 */    if ((value == null) || (value.length() == 0)) {
/*  98: 98 */      throw new IllegalArgumentException("value is empty");
/*  99:    */    }
/* 100:100 */    AttributeType type = getDictionary().getAttributeTypeByName(name);
/* 101:101 */    if (type == null)
/* 102:102 */      throw new IllegalArgumentException("unknown attribute type '" + 
/* 103:103 */        name + "'");
/* 104:104 */    if (type.getVendorId() == -1)
/* 105:105 */      throw new IllegalArgumentException("attribute type '" + name + 
/* 106:106 */        "' is not a Vendor-Specific sub-attribute");
/* 107:107 */    if (type.getVendorId() != getChildVendorId()) {
/* 108:108 */      throw new IllegalArgumentException("attribute type '" + name + 
/* 109:109 */        "' does not belong to vendor ID " + getChildVendorId());
/* 110:    */    }
/* 111:111 */    RadiusAttribute attribute = createRadiusAttribute(getDictionary(), 
/* 112:112 */      getChildVendorId(), type.getTypeCode());
/* 113:113 */    attribute.setAttributeValue(value);
/* 114:114 */    addSubAttribute(attribute);
/* 115:    */  }
/* 116:    */  
/* 120:    */  public void removeSubAttribute(RadiusAttribute attribute)
/* 121:    */  {
/* 122:122 */    if (!this.subAttributes.remove(attribute)) {
/* 123:123 */      throw new IllegalArgumentException("no such attribute");
/* 124:    */    }
/* 125:    */  }
/* 126:    */  
/* 129:    */  public List<RadiusAttribute> getSubAttributes()
/* 130:    */  {
/* 131:131 */    return this.subAttributes;
/* 132:    */  }
/* 133:    */  
/* 138:    */  public List<RadiusAttribute> getSubAttributes(int attributeType)
/* 139:    */  {
/* 140:140 */    if ((attributeType < 1) || (attributeType > 255)) {
/* 141:141 */      throw new IllegalArgumentException(
/* 142:142 */        "sub-attribute type out of bounds");
/* 143:    */    }
/* 144:144 */    LinkedList<RadiusAttribute> result = new LinkedList();
/* 145:145 */    for (Iterator<RadiusAttribute> i = this.subAttributes.iterator(); i.hasNext();) {
/* 146:146 */      RadiusAttribute a = (RadiusAttribute)i.next();
/* 147:147 */      if (attributeType == a.getAttributeType())
/* 148:148 */        result.add(a);
/* 149:    */    }
/* 150:150 */    return result;
/* 151:    */  }
/* 152:    */  
/* 160:    */  public RadiusAttribute getSubAttribute(int type)
/* 161:    */  {
/* 162:162 */    List<RadiusAttribute> attrs = getSubAttributes(type);
/* 163:163 */    if (attrs.size() > 1)
/* 164:164 */      throw new RuntimeException(
/* 165:165 */        "multiple sub-attributes of requested type " + type);
/* 166:166 */    if (attrs.size() == 0) {
/* 167:167 */      return null;
/* 168:    */    }
/* 169:169 */    return (RadiusAttribute)attrs.get(0);
/* 170:    */  }
/* 171:    */  
/* 176:    */  public RadiusAttribute getSubAttribute(String type)
/* 177:    */    throws RadiusException
/* 178:    */  {
/* 179:179 */    if ((type == null) || (type.length() == 0)) {
/* 180:180 */      throw new IllegalArgumentException("type name is empty");
/* 181:    */    }
/* 182:182 */    AttributeType t = getDictionary().getAttributeTypeByName(type);
/* 183:183 */    if (t == null)
/* 184:184 */      throw new IllegalArgumentException("unknown attribute type name '" + 
/* 185:185 */        type + "'");
/* 186:186 */    if (t.getVendorId() != getChildVendorId()) {
/* 187:187 */      throw new IllegalArgumentException("vendor ID mismatch");
/* 188:    */    }
/* 189:189 */    return getSubAttribute(t.getTypeCode());
/* 190:    */  }
/* 191:    */  
/* 199:    */  public String getSubAttributeValue(String type)
/* 200:    */    throws RadiusException
/* 201:    */  {
/* 202:202 */    RadiusAttribute attr = getSubAttribute(type);
/* 203:203 */    if (attr == null) {
/* 204:204 */      return null;
/* 205:    */    }
/* 206:206 */    return attr.getAttributeValue();
/* 207:    */  }
/* 208:    */  
/* 213:    */  public byte[] writeAttribute()
/* 214:    */  {
/* 215:215 */    ByteArrayOutputStream bos = new ByteArrayOutputStream(255);
/* 216:216 */    bos.write(getChildVendorId() >> 24 & 0xFF);
/* 217:217 */    bos.write(getChildVendorId() >> 16 & 0xFF);
/* 218:218 */    bos.write(getChildVendorId() >> 8 & 0xFF);
/* 219:219 */    bos.write(getChildVendorId() & 0xFF);
/* 220:    */    
/* 221:    */    try
/* 222:    */    {
/* 223:223 */      for (Iterator<RadiusAttribute> i = this.subAttributes.iterator(); i.hasNext();) {
/* 224:224 */        RadiusAttribute a = (RadiusAttribute)i.next();
/* 225:225 */        bos.write(a.writeAttribute());
/* 226:    */      }
/* 227:    */    }
/* 228:    */    catch (IOException ioe) {
/* 229:229 */      throw new RuntimeException("error writing data", ioe);
/* 230:    */    }
/* 231:    */    
/* 233:233 */    byte[] attrData = bos.toByteArray();
/* 234:234 */    int len = attrData.length;
/* 235:235 */    if (len > 253) {
/* 236:236 */      throw new RuntimeException("Vendor-Specific attribute too long: " + 
/* 237:237 */        bos.size());
/* 238:    */    }
/* 239:    */    
/* 240:240 */    byte[] attr = new byte[len + 2];
/* 241:241 */    attr[0] = 26;
/* 242:242 */    attr[1] = ((byte)(len + 2));
/* 243:243 */    System.arraycopy(attrData, 0, attr, 2, len);
/* 244:244 */    return attr;
/* 245:    */  }
/* 246:    */  
/* 253:    */  public void readAttribute(byte[] data, int offset, int length)
/* 254:    */    throws RadiusException
/* 255:    */  {
/* 256:256 */    if (length < 6) {
/* 257:257 */      throw new RadiusException("Vendor-Specific attribute too short: " + 
/* 258:258 */        length);
/* 259:    */    }
/* 260:260 */    int vsaCode = data[offset];
/* 261:261 */    int vsaLen = (data[(offset + 1)] & 0xFF) - 6;
/* 262:    */    
/* 263:263 */    if (vsaCode != 26) {
/* 264:264 */      throw new RadiusException("not a Vendor-Specific attribute");
/* 265:    */    }
/* 266:    */    
/* 271:271 */    int vendorId = unsignedByteToInt(data[(offset + 2)]) << 24 | 
/* 272:272 */      unsignedByteToInt(data[(offset + 3)]) << 16 | 
/* 273:273 */      unsignedByteToInt(data[(offset + 4)]) << 8 | unsignedByteToInt(data[(offset + 5)]);
/* 274:274 */    setChildVendorId(vendorId);
/* 275:    */    
/* 277:277 */    int pos = 0;
/* 278:278 */    int count = 0;
/* 279:279 */    while (pos < vsaLen) {
/* 280:280 */      if (pos + 1 >= vsaLen) {
/* 281:281 */        throw new RadiusException("Vendor-Specific attribute malformed");
/* 282:    */      }
/* 283:283 */      int vsaSubLen = data[(offset + 6 + pos + 1)] & 0xFF;
/* 284:284 */      pos += vsaSubLen;
/* 285:285 */      count++;
/* 286:    */    }
/* 287:287 */    if (pos != vsaLen) {
/* 288:288 */      throw new RadiusException("Vendor-Specific attribute malformed");
/* 289:    */    }
/* 290:290 */    this.subAttributes = new ArrayList(count);
/* 291:291 */    pos = 0;
/* 292:292 */    while (pos < vsaLen) {
/* 293:293 */      int subtype = data[(offset + 6 + pos)] & 0xFF;
/* 294:294 */      int sublength = data[(offset + 6 + pos + 1)] & 0xFF;
/* 295:295 */      RadiusAttribute a = createRadiusAttribute(getDictionary(), 
/* 296:296 */        vendorId, subtype);
/* 297:297 */      a.readAttribute(data, offset + 6 + pos, sublength);
/* 298:298 */      this.subAttributes.add(a);
/* 299:299 */      pos += sublength;
/* 300:    */    }
/* 301:    */  }
/* 302:    */  
/* 303:    */  private static int unsignedByteToInt(byte b) {
/* 304:304 */    return b & 0xFF;
/* 305:    */  }
/* 306:    */  
/* 310:    */  public String toString()
/* 311:    */  {
/* 312:312 */    StringBuffer sb = new StringBuffer();
/* 313:313 */    sb.append("Vendor-Specific: ");
/* 314:314 */    int vendorId = getChildVendorId();
/* 315:315 */    String vendorName = getDictionary().getVendorName(vendorId);
/* 316:316 */    if (vendorName != null) {
/* 317:317 */      sb.append(vendorName);
/* 318:318 */      sb.append(" (");
/* 319:319 */      sb.append(vendorId);
/* 320:320 */      sb.append(")");
/* 321:    */    } else {
/* 322:322 */      sb.append("vendor ID ");
/* 323:323 */      sb.append(vendorId);
/* 324:    */    }
/* 325:325 */    for (Iterator<RadiusAttribute> i = getSubAttributes().iterator(); i.hasNext();) {
/* 326:326 */      RadiusAttribute attr = (RadiusAttribute)i.next();
/* 327:327 */      sb.append("\n");
/* 328:328 */      sb.append(attr.toString());
/* 329:    */    }
/* 330:330 */    return sb.toString();
/* 331:    */  }
/* 332:    */  
/* 336:336 */  private List<RadiusAttribute> subAttributes = new ArrayList();
/* 337:    */  private int childVendorId;
/* 338:    */}


/* Location:           D:\cache\windows\Desktop\radius-server-1.0\
 * Qualified Name:     com.radius.server.attribute.VendorSpecificAttribute
 * JD-Core Version:    0.7.0-SNAPSHOT-20130630
 */