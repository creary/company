/*  1:   */package com.radius.server.packet;
/*  2:   */
/*  3:   */import com.radius.server.util.RadiusUtil;
/*  4:   */import java.security.MessageDigest;
/*  5:   */
/*  9:   */public class CoaRequest
/* 10:   */  extends RadiusPacket
/* 11:   */{
/* 12:   */  public CoaRequest()
/* 13:   */  {
/* 14:14 */    super(43, getNextPacketIdentifier());
/* 15:   */  }
/* 16:   */  
/* 20:   */  protected byte[] updateRequestAuthenticator(String sharedSecret, int packetLength, byte[] attributes)
/* 21:   */  {
/* 22:22 */    byte[] authenticator = new byte[16];
/* 23:23 */    for (int i = 0; i < 16; i++)
/* 24:24 */      authenticator[i] = 0;
/* 25:25 */    MessageDigest md5 = getMd5Digest();
/* 26:26 */    md5.reset();
/* 27:27 */    md5.update((byte)getPacketType());
/* 28:28 */    md5.update((byte)getPacketIdentifier());
/* 29:29 */    md5.update((byte)(packetLength >> 8));
/* 30:30 */    md5.update((byte)(packetLength & 0xFF));
/* 31:31 */    md5.update(authenticator, 0, authenticator.length);
/* 32:32 */    md5.update(attributes, 0, attributes.length);
/* 33:33 */    md5.update(RadiusUtil.getUtf8Bytes(sharedSecret));
/* 34:34 */    return md5.digest();
/* 35:   */  }
/* 36:   */}


/* Location:           D:\cache\windows\Desktop\radius-server-1.0\
 * Qualified Name:     com.radius.server.packet.CoaRequest
 * JD-Core Version:    0.7.0-SNAPSHOT-20130630
 */