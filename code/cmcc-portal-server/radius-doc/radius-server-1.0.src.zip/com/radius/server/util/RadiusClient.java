/*   1:    */package com.radius.server.util;
/*   2:    */
/*   3:    */import com.radius.server.packet.AccessRequest;
/*   4:    */import com.radius.server.packet.AccountingRequest;
/*   5:    */import com.radius.server.packet.RadiusPacket;
/*   6:    */import java.io.ByteArrayInputStream;
/*   7:    */import java.io.ByteArrayOutputStream;
/*   8:    */import java.io.IOException;
/*   9:    */import java.net.DatagramPacket;
/*  10:    */import java.net.DatagramSocket;
/*  11:    */import java.net.InetAddress;
/*  12:    */import java.net.InetSocketAddress;
/*  13:    */import java.net.SocketException;
/*  14:    */import java.net.SocketTimeoutException;
/*  15:    */import org.apache.commons.logging.Log;
/*  16:    */import org.apache.commons.logging.LogFactory;
/*  17:    */
/*  38:    */public class RadiusClient
/*  39:    */{
/*  40:    */  public RadiusClient(String hostName, String sharedSecret)
/*  41:    */  {
/*  42: 42 */    setHostName(hostName);
/*  43: 43 */    setSharedSecret(sharedSecret);
/*  44:    */  }
/*  45:    */  
/*  49:    */  public RadiusClient(RadiusEndpoint client)
/*  50:    */  {
/*  51: 51 */    this(client.getEndpointAddress().getAddress().getHostAddress(), client.getSharedSecret());
/*  52:    */  }
/*  53:    */  
/*  62:    */  public synchronized boolean authenticate(String userName, String password)
/*  63:    */    throws IOException, RadiusException
/*  64:    */  {
/*  65: 65 */    AccessRequest request = new AccessRequest(userName, password);
/*  66: 66 */    RadiusPacket response = authenticate(request);
/*  67: 67 */    return response.getPacketType() == 2;
/*  68:    */  }
/*  69:    */  
/*  78:    */  public synchronized RadiusPacket authenticate(AccessRequest request)
/*  79:    */    throws IOException, RadiusException
/*  80:    */  {
/*  81: 81 */    if (logger.isInfoEnabled()) {
/*  82: 82 */      logger.info("send Access-Request packet: " + request);
/*  83:    */    }
/*  84: 84 */    RadiusPacket response = communicate(request, getAuthPort());
/*  85: 85 */    if (logger.isInfoEnabled()) {
/*  86: 86 */      logger.info("received packet: " + response);
/*  87:    */    }
/*  88: 88 */    return response;
/*  89:    */  }
/*  90:    */  
/*  99:    */  public synchronized RadiusPacket account(AccountingRequest request)
/* 100:    */    throws IOException, RadiusException
/* 101:    */  {
/* 102:102 */    if (logger.isInfoEnabled()) {
/* 103:103 */      logger.info("send Accounting-Request packet: " + request);
/* 104:    */    }
/* 105:105 */    RadiusPacket response = communicate(request, getAcctPort());
/* 106:106 */    if (logger.isInfoEnabled()) {
/* 107:107 */      logger.info("received packet: " + response);
/* 108:    */    }
/* 109:109 */    return response;
/* 110:    */  }
/* 111:    */  
/* 114:    */  public void close()
/* 115:    */  {
/* 116:116 */    if (this.socket != null) {
/* 117:117 */      this.socket.close();
/* 118:    */    }
/* 119:    */  }
/* 120:    */  
/* 123:    */  public int getAuthPort()
/* 124:    */  {
/* 125:125 */    return this.authPort;
/* 126:    */  }
/* 127:    */  
/* 131:    */  public void setAuthPort(int authPort)
/* 132:    */  {
/* 133:133 */    if ((authPort < 1) || (authPort > 65535))
/* 134:134 */      throw new IllegalArgumentException("bad port number");
/* 135:135 */    this.authPort = authPort;
/* 136:    */  }
/* 137:    */  
/* 141:    */  public String getHostName()
/* 142:    */  {
/* 143:143 */    return this.hostName;
/* 144:    */  }
/* 145:    */  
/* 149:    */  public void setHostName(String hostName)
/* 150:    */  {
/* 151:151 */    if ((hostName == null) || (hostName.length() == 0))
/* 152:152 */      throw new IllegalArgumentException("host name must not be empty");
/* 153:153 */    this.hostName = hostName;
/* 154:    */  }
/* 155:    */  
/* 159:    */  public int getRetryCount()
/* 160:    */  {
/* 161:161 */    return this.retryCount;
/* 162:    */  }
/* 163:    */  
/* 167:    */  public void setRetryCount(int retryCount)
/* 168:    */  {
/* 169:169 */    if (retryCount < 1)
/* 170:170 */      throw new IllegalArgumentException("retry count must be positive");
/* 171:171 */    this.retryCount = retryCount;
/* 172:    */  }
/* 173:    */  
/* 177:    */  public String getSharedSecret()
/* 178:    */  {
/* 179:179 */    return this.sharedSecret;
/* 180:    */  }
/* 181:    */  
/* 185:    */  public void setSharedSecret(String sharedSecret)
/* 186:    */  {
/* 187:187 */    if ((sharedSecret == null) || (sharedSecret.length() == 0))
/* 188:188 */      throw new IllegalArgumentException("shared secret must not be empty");
/* 189:189 */    this.sharedSecret = sharedSecret;
/* 190:    */  }
/* 191:    */  
/* 195:    */  public int getSocketTimeout()
/* 196:    */  {
/* 197:197 */    return this.socketTimeout;
/* 198:    */  }
/* 199:    */  
/* 204:    */  public void setSocketTimeout(int socketTimeout)
/* 205:    */    throws SocketException
/* 206:    */  {
/* 207:207 */    if (socketTimeout < 1)
/* 208:208 */      throw new IllegalArgumentException("socket tiemout must be positive");
/* 209:209 */    this.socketTimeout = socketTimeout;
/* 210:210 */    if (this.socket != null) {
/* 211:211 */      this.socket.setSoTimeout(socketTimeout);
/* 212:    */    }
/* 213:    */  }
/* 214:    */  
/* 217:    */  public void setAcctPort(int acctPort)
/* 218:    */  {
/* 219:219 */    if ((acctPort < 1) || (acctPort > 65535))
/* 220:220 */      throw new IllegalArgumentException("bad port number");
/* 221:221 */    this.acctPort = acctPort;
/* 222:    */  }
/* 223:    */  
/* 227:    */  public int getAcctPort()
/* 228:    */  {
/* 229:229 */    return this.acctPort;
/* 230:    */  }
/* 231:    */  
/* 240:    */  public RadiusPacket communicate(RadiusPacket request, int port)
/* 241:    */    throws IOException, RadiusException
/* 242:    */  {
/* 243:243 */    DatagramPacket packetIn = new DatagramPacket(new byte[4096], 4096);
/* 244:244 */    DatagramPacket packetOut = makeDatagramPacket(request, port);
/* 245:    */    
/* 246:246 */    DatagramSocket socket = getSocket();
/* 247:247 */    for (int i = 1; i <= getRetryCount(); i++) {
/* 248:    */      try {
/* 249:249 */        socket.send(packetOut);
/* 250:250 */        socket.receive(packetIn);
/* 251:251 */        return makeRadiusPacket(packetIn, request);
/* 252:    */      } catch (IOException ioex) {
/* 253:253 */        if (i == getRetryCount()) {
/* 254:254 */          if (logger.isErrorEnabled()) {
/* 255:255 */            if ((ioex instanceof SocketTimeoutException)) {
/* 256:256 */              logger.error("communication failure (timeout), no more retries");
/* 257:    */            } else
/* 258:258 */              logger.error("communication failure, no more retries", ioex);
/* 259:    */          }
/* 260:260 */          throw ioex;
/* 261:    */        }
/* 262:262 */        if (logger.isInfoEnabled()) {
/* 263:263 */          logger.info("communication failure, retry " + i);
/* 264:    */        }
/* 265:    */      }
/* 266:    */    }
/* 267:    */    
/* 270:270 */    return null;
/* 271:    */  }
/* 272:    */  
/* 281:    */  public static RadiusPacket communicate(RadiusEndpoint remoteServer, RadiusPacket request)
/* 282:    */    throws RadiusException, IOException
/* 283:    */  {
/* 284:284 */    RadiusClient rc = new RadiusClient(remoteServer);
/* 285:285 */    return rc.communicate(request, remoteServer.getEndpointAddress().getPort());
/* 286:    */  }
/* 287:    */  
/* 293:    */  protected DatagramSocket getSocket()
/* 294:    */    throws SocketException
/* 295:    */  {
/* 296:296 */    if (this.socket == null) {
/* 297:297 */      this.socket = new DatagramSocket();
/* 298:298 */      this.socket.setSoTimeout(getSocketTimeout());
/* 299:    */    }
/* 300:300 */    return this.socket;
/* 301:    */  }
/* 302:    */  
/* 309:    */  protected DatagramPacket makeDatagramPacket(RadiusPacket packet, int port)
/* 310:    */    throws IOException
/* 311:    */  {
/* 312:312 */    ByteArrayOutputStream bos = new ByteArrayOutputStream();
/* 313:313 */    packet.encodeRequestPacket(bos, getSharedSecret());
/* 314:314 */    byte[] data = bos.toByteArray();
/* 315:    */    
/* 316:316 */    InetAddress address = InetAddress.getByName(getHostName());
/* 317:317 */    DatagramPacket datagram = new DatagramPacket(data, data.length, address, port);
/* 318:318 */    return datagram;
/* 319:    */  }
/* 320:    */  
/* 326:    */  protected RadiusPacket makeRadiusPacket(DatagramPacket packet, RadiusPacket request)
/* 327:    */    throws IOException, RadiusException
/* 328:    */  {
/* 329:329 */    ByteArrayInputStream in = new ByteArrayInputStream(packet.getData());
/* 330:330 */    return RadiusPacket.decodeResponsePacket(in, getSharedSecret(), request);
/* 331:    */  }
/* 332:    */  
/* 333:333 */  private int authPort = 1812;
/* 334:334 */  private int acctPort = 1813;
/* 335:335 */  private String hostName = null;
/* 336:336 */  private String sharedSecret = null;
/* 337:337 */  private DatagramSocket socket = null;
/* 338:338 */  private int retryCount = 3;
/* 339:339 */  private int socketTimeout = 3000;
/* 340:340 */  private static Log logger = LogFactory.getLog(RadiusClient.class);
/* 341:    */}


/* Location:           D:\cache\windows\Desktop\radius-server-1.0\
 * Qualified Name:     com.radius.server.util.RadiusClient
 * JD-Core Version:    0.7.0-SNAPSHOT-20130630
 */