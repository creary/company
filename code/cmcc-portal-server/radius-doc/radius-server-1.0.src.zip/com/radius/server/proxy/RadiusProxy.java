/*   1:    */package com.radius.server.proxy;
/*   2:    */
/*   3:    */import com.radius.server.attribute.RadiusAttribute;
/*   4:    */import com.radius.server.packet.RadiusPacket;
/*   5:    */import com.radius.server.util.RadiusEndpoint;
/*   6:    */import com.radius.server.util.RadiusException;
/*   7:    */import com.radius.server.util.RadiusServer;
/*   8:    */import java.io.ByteArrayOutputStream;
/*   9:    */import java.io.IOException;
/*  10:    */import java.net.DatagramPacket;
/*  11:    */import java.net.DatagramSocket;
/*  12:    */import java.net.InetAddress;
/*  13:    */import java.net.InetSocketAddress;
/*  14:    */import java.net.SocketException;
/*  15:    */import java.util.HashMap;
/*  16:    */import java.util.List;
/*  17:    */import java.util.Map;
/*  18:    */import org.apache.commons.logging.Log;
/*  19:    */import org.apache.commons.logging.LogFactory;
/*  20:    */
/*  37:    */public abstract class RadiusProxy
/*  38:    */  extends RadiusServer
/*  39:    */{
/*  40:    */  public void start(boolean listenAuth, boolean listenAcct, boolean listenProxy)
/*  41:    */  {
/*  42: 42 */    super.start(listenAuth, listenAcct);
/*  43: 43 */    if (listenProxy)
/*  44:    */    {
/*  54: 54 */      new Thread() {
/*  55:    */        public void run() {
/*  56: 46 */          setName("Radius Proxy Listener");
/*  57:    */          try {
/*  58: 48 */            RadiusProxy.logger.info("starting RadiusProxyListener on port " + RadiusProxy.this.getProxyPort());
/*  59: 49 */            RadiusProxy.this.listen(RadiusProxy.this.getProxySocket());
/*  60:    */          } catch (Exception e) {
/*  61: 51 */            e.printStackTrace();
/*  62:    */          }
/*  63:    */        }
/*  64:    */      }.start();
/*  65:    */    }
/*  66:    */  }
/*  67:    */  
/*  70:    */  public void stop()
/*  71:    */  {
/*  72: 62 */    logger.info("stopping Radius proxy");
/*  73: 63 */    if (this.proxySocket != null)
/*  74: 64 */      this.proxySocket.close();
/*  75: 65 */    super.stop();
/*  76:    */  }
/*  77:    */  
/*  85:    */  public abstract RadiusEndpoint getProxyServer(RadiusPacket paramRadiusPacket, RadiusEndpoint paramRadiusEndpoint);
/*  86:    */  
/*  94:    */  public int getProxyPort()
/*  95:    */  {
/*  96: 86 */    return this.proxyPort;
/*  97:    */  }
/*  98:    */  
/* 103:    */  public void setProxyPort(int proxyPort)
/* 104:    */  {
/* 105: 95 */    this.proxyPort = proxyPort;
/* 106: 96 */    this.proxySocket = null;
/* 107:    */  }
/* 108:    */  
/* 113:    */  public void setSocketTimeout(int socketTimeout)
/* 114:    */    throws SocketException
/* 115:    */  {
/* 116:106 */    super.setSocketTimeout(socketTimeout);
/* 117:107 */    if (this.proxySocket != null) {
/* 118:108 */      this.proxySocket.setSoTimeout(socketTimeout);
/* 119:    */    }
/* 120:    */  }
/* 121:    */  
/* 125:    */  protected DatagramSocket getProxySocket()
/* 126:    */    throws SocketException
/* 127:    */  {
/* 128:118 */    if (this.proxySocket == null) {
/* 129:119 */      if (getListenAddress() == null) {
/* 130:120 */        this.proxySocket = new DatagramSocket(getProxyPort());
/* 131:    */      } else
/* 132:122 */        this.proxySocket = new DatagramSocket(getProxyPort(), getListenAddress());
/* 133:123 */      this.proxySocket.setSoTimeout(getSocketTimeout());
/* 134:    */    }
/* 135:125 */    return this.proxySocket;
/* 136:    */  }
/* 137:    */  
/* 142:    */  protected RadiusPacket handlePacket(InetSocketAddress localAddress, InetSocketAddress remoteAddress, RadiusPacket request, String sharedSecret)
/* 143:    */    throws RadiusException, IOException
/* 144:    */  {
/* 145:135 */    if (localAddress.getPort() == getProxyPort()) {
/* 146:136 */      proxyPacketReceived(request, remoteAddress);
/* 147:137 */      return null;
/* 148:    */    }
/* 149:    */    
/* 151:141 */    RadiusEndpoint radiusClient = new RadiusEndpoint(remoteAddress, sharedSecret);
/* 152:142 */    RadiusEndpoint radiusServer = getProxyServer(request, radiusClient);
/* 153:143 */    if (radiusServer != null)
/* 154:    */    {
/* 155:145 */      RadiusProxyConnection proxyConnection = new RadiusProxyConnection(radiusServer, radiusClient, request, localAddress.getPort());
/* 156:146 */      logger.info("proxy packet to " + proxyConnection);
/* 157:147 */      proxyPacket(request, proxyConnection);
/* 158:148 */      return null;
/* 159:    */    }
/* 160:    */    
/* 161:151 */    return super.handlePacket(localAddress, remoteAddress, request, sharedSecret);
/* 162:    */  }
/* 163:    */  
/* 172:    */  protected void proxyPacketReceived(RadiusPacket packet, InetSocketAddress remote)
/* 173:    */    throws IOException, RadiusException
/* 174:    */  {
/* 175:165 */    List<RadiusAttribute> proxyStates = packet.getAttributes(33);
/* 176:166 */    if ((proxyStates == null) || (proxyStates.size() == 0))
/* 177:167 */      throw new RadiusException("proxy packet without Proxy-State attribute");
/* 178:168 */    RadiusAttribute proxyState = (RadiusAttribute)proxyStates.get(proxyStates.size() - 1);
/* 179:    */    
/* 181:171 */    String state = new String(proxyState.getAttributeData());
/* 182:172 */    RadiusProxyConnection proxyConnection = (RadiusProxyConnection)this.proxyConnections.remove(state);
/* 183:173 */    if (proxyConnection == null) {
/* 184:174 */      logger.warn("received packet on proxy port without saved proxy connection - duplicate?");
/* 185:175 */      return;
/* 186:    */    }
/* 187:    */    
/* 189:179 */    RadiusEndpoint client = proxyConnection.getRadiusClient();
/* 190:180 */    if (logger.isInfoEnabled()) {
/* 191:181 */      logger.info("received proxy packet: " + packet);
/* 192:182 */      logger.info("forward packet to " + client.getEndpointAddress().toString() + " with secret " + client.getSharedSecret());
/* 193:    */    }
/* 194:    */    
/* 196:186 */    packet.removeLastAttribute(33);
/* 197:    */    
/* 199:189 */    RadiusPacket answer = new RadiusPacket(packet.getPacketType(), packet.getPacketIdentifier(), packet.getAttributes());
/* 200:190 */    DatagramPacket datagram = makeDatagramPacket(answer, client.getSharedSecret(), client.getEndpointAddress().getAddress(), client.getEndpointAddress().getPort(), proxyConnection.getPacket());
/* 201:    */    
/* 202:    */    DatagramSocket socket;
/* 203:    */    DatagramSocket socket;
/* 204:194 */    if (proxyConnection.getPort() == getAuthPort()) {
/* 205:195 */      socket = getAuthSocket();
/* 206:    */    } else
/* 207:197 */      socket = getAcctSocket();
/* 208:198 */    socket.send(datagram);
/* 209:    */  }
/* 210:    */  
/* 218:    */  protected void proxyPacket(RadiusPacket packet, RadiusProxyConnection proxyConnection)
/* 219:    */    throws IOException
/* 220:    */  {
/* 221:211 */    synchronized (RadiusProxy.class)
/* 222:    */    {
/* 223:213 */      this.proxyIndex += 1;
/* 224:214 */      String proxyIndexStr = Integer.toString(this.proxyIndex);
/* 225:215 */      packet.addAttribute(new RadiusAttribute(33, proxyIndexStr.getBytes()));
/* 226:    */      
/* 228:218 */      this.proxyConnections.put(proxyIndexStr, proxyConnection);
/* 229:    */    }
/* 230:    */    
/* 232:222 */    InetAddress serverAddress = proxyConnection.getRadiusServer().getEndpointAddress().getAddress();
/* 233:223 */    int serverPort = proxyConnection.getRadiusServer().getEndpointAddress().getPort();
/* 234:224 */    String serverSecret = proxyConnection.getRadiusServer().getSharedSecret();
/* 235:    */    
/* 237:227 */    byte[] auth = packet.getAuthenticator();
/* 238:    */    
/* 240:230 */    ByteArrayOutputStream bos = new ByteArrayOutputStream();
/* 241:231 */    packet.encodeRequestPacket(bos, serverSecret);
/* 242:232 */    byte[] data = bos.toByteArray();
/* 243:233 */    DatagramPacket datagram = new DatagramPacket(data, data.length, serverAddress, serverPort);
/* 244:    */    
/* 246:236 */    packet.setAuthenticator(auth);
/* 247:    */    
/* 249:239 */    DatagramSocket proxySocket = getProxySocket();
/* 250:240 */    proxySocket.send(datagram);
/* 251:    */  }
/* 252:    */  
/* 256:246 */  private int proxyIndex = 1;
/* 257:    */  
/* 263:253 */  private Map<String, RadiusProxyConnection> proxyConnections = new HashMap();
/* 264:    */  
/* 265:255 */  private int proxyPort = 1814;
/* 266:256 */  private DatagramSocket proxySocket = null;
/* 267:257 */  private static Log logger = LogFactory.getLog(RadiusProxy.class);
/* 268:    */}


/* Location:           D:\cache\windows\Desktop\radius-server-1.0\
 * Qualified Name:     com.radius.server.proxy.RadiusProxy
 * JD-Core Version:    0.7.0-SNAPSHOT-20130630
 */