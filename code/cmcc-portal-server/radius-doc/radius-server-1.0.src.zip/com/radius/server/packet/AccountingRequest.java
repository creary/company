/*   1:    */package com.radius.server.packet;
/*   2:    */
/*   3:    */import com.radius.server.attribute.IntegerAttribute;
/*   4:    */import com.radius.server.attribute.RadiusAttribute;
/*   5:    */import com.radius.server.attribute.StringAttribute;
/*   6:    */import com.radius.server.util.RadiusException;
/*   7:    */import com.radius.server.util.RadiusUtil;
/*   8:    */import java.security.MessageDigest;
/*   9:    */import java.util.List;
/*  10:    */
/*  42:    */public class AccountingRequest
/*  43:    */  extends RadiusPacket
/*  44:    */{
/*  45:    */  public static final int ACCT_STATUS_TYPE_START = 1;
/*  46:    */  public static final int ACCT_STATUS_TYPE_STOP = 2;
/*  47:    */  public static final int ACCT_STATUS_TYPE_INTERIM_UPDATE = 3;
/*  48:    */  public static final int ACCT_STATUS_TYPE_ACCOUNTING_ON = 7;
/*  49:    */  public static final int ACCT_STATUS_TYPE_ACCOUNTING_OFF = 8;
/*  50:    */  private static final int USER_NAME = 1;
/*  51:    */  private static final int ACCT_STATUS_TYPE = 40;
/*  52:    */  
/*  53:    */  public AccountingRequest(String userName, int acctStatusType)
/*  54:    */  {
/*  55: 55 */    super(4, getNextPacketIdentifier());
/*  56: 56 */    setUserName(userName);
/*  57: 57 */    setAcctStatusType(acctStatusType);
/*  58:    */  }
/*  59:    */  
/*  65:    */  public AccountingRequest() {}
/*  66:    */  
/*  71:    */  public void setUserName(String userName)
/*  72:    */  {
/*  73: 73 */    if (userName == null)
/*  74: 74 */      throw new NullPointerException("user name not set");
/*  75: 75 */    if (userName.length() == 0) {
/*  76: 76 */      throw new IllegalArgumentException("empty user name not allowed");
/*  77:    */    }
/*  78: 78 */    removeAttributes(1);
/*  79: 79 */    addAttribute(new StringAttribute(1, userName));
/*  80:    */  }
/*  81:    */  
/*  85:    */  public String getUserName()
/*  86:    */    throws RadiusException
/*  87:    */  {
/*  88: 88 */    List<RadiusAttribute> attrs = getAttributes(1);
/*  89: 89 */    if ((attrs.size() < 1) || (attrs.size() > 1)) {
/*  90: 90 */      throw new RuntimeException("exactly one User-Name attribute required");
/*  91:    */    }
/*  92: 92 */    RadiusAttribute ra = (RadiusAttribute)attrs.get(0);
/*  93: 93 */    return ra.getAttributeValue();
/*  94:    */  }
/*  95:    */  
/*  99:    */  public void setAcctStatusType(int acctStatusType)
/* 100:    */  {
/* 101:101 */    if ((acctStatusType < 1) || (acctStatusType > 15))
/* 102:102 */      throw new IllegalArgumentException("bad Acct-Status-Type");
/* 103:103 */    removeAttributes(40);
/* 104:104 */    addAttribute(new IntegerAttribute(40, acctStatusType));
/* 105:    */  }
/* 106:    */  
/* 110:    */  public int getAcctStatusType()
/* 111:    */    throws RadiusException
/* 112:    */  {
/* 113:113 */    RadiusAttribute ra = getAttribute(40);
/* 114:114 */    if (ra == null) {
/* 115:115 */      return -1;
/* 116:    */    }
/* 117:117 */    return ((IntegerAttribute)ra).getAttributeValueInt();
/* 118:    */  }
/* 119:    */  
/* 123:    */  protected byte[] updateRequestAuthenticator(String sharedSecret, int packetLength, byte[] attributes)
/* 124:    */  {
/* 125:125 */    byte[] authenticator = new byte[16];
/* 126:126 */    for (int i = 0; i < 16; i++) {
/* 127:127 */      authenticator[i] = 0;
/* 128:    */    }
/* 129:129 */    MessageDigest md5 = getMd5Digest();
/* 130:130 */    md5.reset();
/* 131:131 */    md5.update((byte)getPacketType());
/* 132:132 */    md5.update((byte)getPacketIdentifier());
/* 133:133 */    md5.update((byte)(packetLength >> 8));
/* 134:134 */    md5.update((byte)(packetLength & 0xFF));
/* 135:135 */    md5.update(authenticator, 0, authenticator.length);
/* 136:136 */    md5.update(attributes, 0, attributes.length);
/* 137:137 */    md5.update(RadiusUtil.getUtf8Bytes(sharedSecret));
/* 138:138 */    return md5.digest();
/* 139:    */  }
/* 140:    */  
/* 142:    */  protected void checkRequestAuthenticator(String sharedSecret, int packetLength, byte[] attributes)
/* 143:    */    throws RadiusException
/* 144:    */  {
/* 145:145 */    byte[] expectedAuthenticator = updateRequestAuthenticator(sharedSecret, packetLength, attributes);
/* 146:146 */    byte[] receivedAuth = getAuthenticator();
/* 147:147 */    for (int i = 0; i < 16; i++) {
/* 148:148 */      if (expectedAuthenticator[i] != receivedAuth[i]) {
/* 149:149 */        throw new RadiusException("request authenticator invalid");
/* 150:    */      }
/* 151:    */    }
/* 152:    */  }
/* 153:    */}


/* Location:           D:\cache\windows\Desktop\radius-server-1.0\
 * Qualified Name:     com.radius.server.packet.AccountingRequest
 * JD-Core Version:    0.7.0-SNAPSHOT-20130630
 */