package com.radius.server.util;

import java.net.InetSocketAddress;

class ReceivedPacket
{
  public int packetIdentifier;
  public long receiveTime;
  public InetSocketAddress address;
  public byte[] authenticator;
}


/* Location:           D:\cache\windows\Desktop\radius-server-1.0\
 * Qualified Name:     com.radius.server.util.ReceivedPacket
 * JD-Core Version:    0.7.0-SNAPSHOT-20130630
 */