/*    1:     */package com.radius.server.packet;
/*    2:     */
/*    3:     */import com.radius.server.attribute.RadiusAttribute;
/*    4:     */import com.radius.server.attribute.VendorSpecificAttribute;
/*    5:     */import com.radius.server.dictionary.AttributeType;
/*    6:     */import com.radius.server.dictionary.DefaultDictionary;
/*    7:     */import com.radius.server.dictionary.Dictionary;
/*    8:     */import com.radius.server.util.RadiusException;
/*    9:     */import com.radius.server.util.RadiusUtil;
/*   10:     */import java.io.ByteArrayOutputStream;
/*   11:     */import java.io.DataOutputStream;
/*   12:     */import java.io.IOException;
/*   13:     */import java.io.InputStream;
/*   14:     */import java.io.OutputStream;
/*   15:     */import java.security.MessageDigest;
/*   16:     */import java.security.NoSuchAlgorithmException;
/*   17:     */import java.security.SecureRandom;
/*   18:     */import java.util.ArrayList;
/*   19:     */import java.util.Iterator;
/*   20:     */import java.util.LinkedList;
/*   21:     */import java.util.List;
/*   22:     */
/*   50:     */public class RadiusPacket
/*   51:     */{
/*   52:     */  public static final int ACCESS_REQUEST = 1;
/*   53:     */  public static final int ACCESS_ACCEPT = 2;
/*   54:     */  public static final int ACCESS_REJECT = 3;
/*   55:     */  public static final int ACCOUNTING_REQUEST = 4;
/*   56:     */  public static final int ACCOUNTING_RESPONSE = 5;
/*   57:     */  public static final int ACCOUNTING_STATUS = 6;
/*   58:     */  public static final int PASSWORD_REQUEST = 7;
/*   59:     */  public static final int PASSWORD_ACCEPT = 8;
/*   60:     */  public static final int PASSWORD_REJECT = 9;
/*   61:     */  public static final int ACCOUNTING_MESSAGE = 10;
/*   62:     */  public static final int ACCESS_CHALLENGE = 11;
/*   63:     */  public static final int STATUS_SERVER = 12;
/*   64:     */  public static final int STATUS_CLIENT = 13;
/*   65:     */  public static final int DISCONNECT_REQUEST = 40;
/*   66:     */  public static final int DISCONNECT_ACK = 41;
/*   67:     */  public static final int DISCONNECT_NAK = 42;
/*   68:     */  public static final int COA_REQUEST = 43;
/*   69:     */  public static final int COA_ACK = 44;
/*   70:     */  public static final int COA_NAK = 45;
/*   71:     */  public static final int STATUS_REQUEST = 46;
/*   72:     */  public static final int STATUS_ACCEPT = 47;
/*   73:     */  public static final int STATUS_REJECT = 48;
/*   74:     */  public static final int RESERVED = 255;
/*   75:     */  public static final int MAX_PACKET_LENGTH = 4096;
/*   76:     */  public static final int RADIUS_HEADER_LENGTH = 20;
/*   77:     */  
/*   78:     */  public RadiusPacket(int type)
/*   79:     */  {
/*   80:  80 */    this(type, getNextPacketIdentifier(), new ArrayList());
/*   81:     */  }
/*   82:     */  
/*   88:     */  public RadiusPacket(int type, int identifier)
/*   89:     */  {
/*   90:  90 */    this(type, identifier, new ArrayList());
/*   91:     */  }
/*   92:     */  
/*   99:     */  public RadiusPacket(int type, int identifier, List<RadiusAttribute> attributes)
/*  100:     */  {
/*  101: 101 */    setPacketType(type);
/*  102: 102 */    setPacketIdentifier(identifier);
/*  103: 103 */    setAttributes(attributes);
/*  104:     */  }
/*  105:     */  
/*  110:     */  public RadiusPacket() {}
/*  111:     */  
/*  115:     */  public int getPacketIdentifier()
/*  116:     */  {
/*  117: 117 */    return this.packetIdentifier;
/*  118:     */  }
/*  119:     */  
/*  123:     */  public void setPacketIdentifier(int identifier)
/*  124:     */  {
/*  125: 125 */    if ((identifier < 0) || (identifier > 255))
/*  126: 126 */      throw new IllegalArgumentException("packet identifier out of bounds");
/*  127: 127 */    this.packetIdentifier = identifier;
/*  128:     */  }
/*  129:     */  
/*  133:     */  public int getPacketType()
/*  134:     */  {
/*  135: 135 */    return this.packetType;
/*  136:     */  }
/*  137:     */  
/*  141:     */  public String getPacketTypeName()
/*  142:     */  {
/*  143: 143 */    switch (getPacketType()) {
/*  144: 144 */    case 1:  return "Access-Request";
/*  145: 145 */    case 2:  return "Access-Accept";
/*  146: 146 */    case 3:  return "Access-Reject";
/*  147: 147 */    case 4:  return "Accounting-Request";
/*  148: 148 */    case 5:  return "Accounting-Response";
/*  149: 149 */    case 6:  return "Accounting-Status";
/*  150: 150 */    case 7:  return "Password-Request";
/*  151: 151 */    case 8:  return "Password-Accept";
/*  152: 152 */    case 9:  return "Password-Reject";
/*  153: 153 */    case 10:  return "Accounting-Message";
/*  154: 154 */    case 11:  return "Access-Challenge";
/*  155: 155 */    case 12:  return "Status-Server";
/*  156: 156 */    case 13:  return "Status-Client";
/*  157:     */    case 40: 
/*  158: 158 */      return "Disconnect-Request";
/*  159: 159 */    case 41:  return "Disconnect-ACK";
/*  160: 160 */    case 42:  return "Disconnect-NAK";
/*  161: 161 */    case 43:  return "CoA-Request";
/*  162: 162 */    case 44:  return "CoA-ACK";
/*  163: 163 */    case 45:  return "CoA-NAK";
/*  164: 164 */    case 46:  return "Status-Request";
/*  165: 165 */    case 47:  return "Status-Accept";
/*  166: 166 */    case 48:  return "Status-Reject";
/*  167: 167 */    case 255:  return "Reserved"; }
/*  168: 168 */    return "Unknown (" + getPacketType() + ")";
/*  169:     */  }
/*  170:     */  
/*  175:     */  public void setPacketType(int type)
/*  176:     */  {
/*  177: 177 */    if ((type < 1) || (type > 255))
/*  178: 178 */      throw new IllegalArgumentException("packet type out of bounds");
/*  179: 179 */    this.packetType = type;
/*  180:     */  }
/*  181:     */  
/*  185:     */  public void setAttributes(List<RadiusAttribute> attributes)
/*  186:     */  {
/*  187: 187 */    if (attributes == null) {
/*  188: 188 */      throw new NullPointerException("attributes list is null");
/*  189:     */    }
/*  190:     */    
/*  196: 196 */    this.attributes = attributes;
/*  197:     */  }
/*  198:     */  
/*  205:     */  public void addAttribute(RadiusAttribute attribute)
/*  206:     */  {
/*  207: 207 */    if (attribute == null)
/*  208: 208 */      throw new NullPointerException("attribute is null");
/*  209: 209 */    attribute.setDictionary(getDictionary());
/*  210: 210 */    if (attribute.getVendorId() == -1) {
/*  211: 211 */      this.attributes.add(attribute);
/*  212:     */    } else {
/*  213: 213 */      VendorSpecificAttribute vsa = new VendorSpecificAttribute(attribute.getVendorId());
/*  214: 214 */      vsa.addSubAttribute(attribute);
/*  215: 215 */      this.attributes.add(vsa);
/*  216:     */    }
/*  217:     */  }
/*  218:     */  
/*  227:     */  public void addAttribute(String typeName, String value)
/*  228:     */  {
/*  229: 229 */    if ((typeName == null) || (typeName.length() == 0))
/*  230: 230 */      throw new IllegalArgumentException("type name is empty");
/*  231: 231 */    if ((value == null) || (value.length() == 0)) {
/*  232: 232 */      throw new IllegalArgumentException("value is empty");
/*  233:     */    }
/*  234: 234 */    AttributeType type = this.dictionary.getAttributeTypeByName(typeName);
/*  235: 235 */    if (type == null) {
/*  236: 236 */      throw new IllegalArgumentException("unknown attribute type '" + typeName + "'");
/*  237:     */    }
/*  238: 238 */    RadiusAttribute attribute = RadiusAttribute.createRadiusAttribute(getDictionary(), type.getVendorId(), type.getTypeCode());
/*  239: 239 */    attribute.setAttributeValue(value);
/*  240: 240 */    addAttribute(attribute);
/*  241:     */  }
/*  242:     */  
/*  246:     */  public void removeAttribute(RadiusAttribute attribute)
/*  247:     */  {
/*  248: 248 */    if (attribute.getVendorId() == -1) {
/*  249: 249 */      if (!this.attributes.remove(attribute)) {
/*  250: 250 */        throw new IllegalArgumentException("no such attribute");
/*  251:     */      }
/*  252:     */    } else {
/*  253: 253 */      List<VendorSpecificAttribute> vsas = getVendorAttributes(attribute.getVendorId());
/*  254: 254 */      for (Iterator<VendorSpecificAttribute> i = vsas.iterator(); i.hasNext();) {
/*  255: 255 */        VendorSpecificAttribute vsa = (VendorSpecificAttribute)i.next();
/*  256: 256 */        List<RadiusAttribute> sas = vsa.getSubAttributes();
/*  257: 257 */        if (sas.contains(attribute)) {
/*  258: 258 */          vsa.removeSubAttribute(attribute);
/*  259: 259 */          if (sas.size() == 1)
/*  260:     */          {
/*  262: 262 */            removeAttribute(vsa);
/*  263:     */          }
/*  264:     */        }
/*  265:     */      }
/*  266:     */    }
/*  267:     */  }
/*  268:     */  
/*  272:     */  public void removeAttributes(int type)
/*  273:     */  {
/*  274: 274 */    if ((type < 1) || (type > 255)) {
/*  275: 275 */      throw new IllegalArgumentException("attribute type out of bounds");
/*  276:     */    }
/*  277: 277 */    Iterator<RadiusAttribute> i = this.attributes.iterator();
/*  278: 278 */    while (i.hasNext()) {
/*  279: 279 */      RadiusAttribute attribute = (RadiusAttribute)i.next();
/*  280: 280 */      if (attribute.getAttributeType() == type) {
/*  281: 281 */        i.remove();
/*  282:     */      }
/*  283:     */    }
/*  284:     */  }
/*  285:     */  
/*  289:     */  public void removeLastAttribute(int type)
/*  290:     */  {
/*  291: 291 */    List<RadiusAttribute> attrs = getAttributes(type);
/*  292: 292 */    if ((attrs == null) || (attrs.size() == 0)) {
/*  293: 293 */      return;
/*  294:     */    }
/*  295: 295 */    RadiusAttribute lastAttribute = (RadiusAttribute)attrs.get(attrs.size() - 1);
/*  296: 296 */    removeAttribute(lastAttribute);
/*  297:     */  }
/*  298:     */  
/*  304:     */  public void removeAttributes(int vendorId, int typeCode)
/*  305:     */  {
/*  306: 306 */    if (vendorId == -1) {
/*  307: 307 */      removeAttributes(typeCode);
/*  308: 308 */      return;
/*  309:     */    }
/*  310:     */    
/*  311: 311 */    List<VendorSpecificAttribute> vsas = getVendorAttributes(vendorId);
/*  312: 312 */    for (Iterator<VendorSpecificAttribute> i = vsas.iterator(); i.hasNext();) {
/*  313: 313 */      VendorSpecificAttribute vsa = (VendorSpecificAttribute)i.next();
/*  314:     */      
/*  315: 315 */      List<RadiusAttribute> sas = vsa.getSubAttributes();
/*  316: 316 */      for (Iterator<RadiusAttribute> j = sas.iterator(); j.hasNext();) {
/*  317: 317 */        RadiusAttribute attr = (RadiusAttribute)j.next();
/*  318: 318 */        if ((attr.getAttributeType() == typeCode) && 
/*  319: 319 */          (attr.getVendorId() == vendorId))
/*  320: 320 */          j.remove();
/*  321:     */      }
/*  322: 322 */      if (sas.size() == 0)
/*  323:     */      {
/*  325: 325 */        removeAttribute(vsa);
/*  326:     */      }
/*  327:     */    }
/*  328:     */  }
/*  329:     */  
/*  334:     */  public List<RadiusAttribute> getAttributes(int attributeType)
/*  335:     */  {
/*  336: 336 */    if ((attributeType < 1) || (attributeType > 255)) {
/*  337: 337 */      throw new IllegalArgumentException("attribute type out of bounds");
/*  338:     */    }
/*  339: 339 */    LinkedList<RadiusAttribute> result = new LinkedList();
/*  340: 340 */    for (Iterator<RadiusAttribute> i = this.attributes.iterator(); i.hasNext();) {
/*  341: 341 */      RadiusAttribute a = (RadiusAttribute)i.next();
/*  342: 342 */      if (attributeType == a.getAttributeType())
/*  343: 343 */        result.add(a);
/*  344:     */    }
/*  345: 345 */    return result;
/*  346:     */  }
/*  347:     */  
/*  355:     */  public List<RadiusAttribute> getAttributes(int vendorId, int attributeType)
/*  356:     */  {
/*  357: 357 */    if (vendorId == -1) {
/*  358: 358 */      return getAttributes(attributeType);
/*  359:     */    }
/*  360: 360 */    LinkedList<RadiusAttribute> result = new LinkedList();
/*  361: 361 */    List<VendorSpecificAttribute> vsas = getVendorAttributes(vendorId);
/*  362: 362 */    Iterator<RadiusAttribute> j; for (Iterator<VendorSpecificAttribute> i = vsas.iterator(); i.hasNext(); 
/*  363:     */        
/*  365: 365 */        j.hasNext())
/*  366:     */    {
/*  367: 363 */      VendorSpecificAttribute vsa = (VendorSpecificAttribute)i.next();
/*  368: 364 */      List<RadiusAttribute> sas = vsa.getSubAttributes();
/*  369: 365 */      j = sas.iterator();continue;
/*  370: 366 */      RadiusAttribute attr = (RadiusAttribute)j.next();
/*  371: 367 */      if ((attr.getAttributeType() == attributeType) && 
/*  372: 368 */        (attr.getVendorId() == vendorId)) {
/*  373: 369 */        result.add(attr);
/*  374:     */      }
/*  375:     */    }
/*  376:     */    
/*  377: 373 */    return result;
/*  378:     */  }
/*  379:     */  
/*  384:     */  public List<RadiusAttribute> getAttributes()
/*  385:     */  {
/*  386: 382 */    return this.attributes;
/*  387:     */  }
/*  388:     */  
/*  396:     */  public RadiusAttribute getAttribute(int type)
/*  397:     */  {
/*  398: 394 */    List<RadiusAttribute> attrs = getAttributes(type);
/*  399: 395 */    if (attrs.size() > 1)
/*  400: 396 */      throw new RuntimeException("multiple attributes of requested type " + type);
/*  401: 397 */    if (attrs.size() == 0) {
/*  402: 398 */      return null;
/*  403:     */    }
/*  404: 400 */    return (RadiusAttribute)attrs.get(0);
/*  405:     */  }
/*  406:     */  
/*  415:     */  public RadiusAttribute getAttribute(int vendorId, int type)
/*  416:     */  {
/*  417: 413 */    if (vendorId == -1) {
/*  418: 414 */      return getAttribute(type);
/*  419:     */    }
/*  420: 416 */    List<RadiusAttribute> attrs = getAttributes(vendorId, type);
/*  421: 417 */    if (attrs.size() > 1)
/*  422: 418 */      throw new RuntimeException("multiple attributes of requested type " + type);
/*  423: 419 */    if (attrs.size() == 0) {
/*  424: 420 */      return null;
/*  425:     */    }
/*  426: 422 */    return (RadiusAttribute)attrs.get(0);
/*  427:     */  }
/*  428:     */  
/*  435:     */  public RadiusAttribute getAttribute(String type)
/*  436:     */  {
/*  437: 433 */    if ((type == null) || (type.length() == 0)) {
/*  438: 434 */      throw new IllegalArgumentException("type name is empty");
/*  439:     */    }
/*  440: 436 */    AttributeType t = this.dictionary.getAttributeTypeByName(type);
/*  441: 437 */    if (t == null) {
/*  442: 438 */      throw new IllegalArgumentException("unknown attribute type name '" + type + "'");
/*  443:     */    }
/*  444: 440 */    return getAttribute(t.getVendorId(), t.getTypeCode());
/*  445:     */  }
/*  446:     */  
/*  456:     */  public String getAttributeValue(String type)
/*  457:     */  {
/*  458: 454 */    RadiusAttribute attr = getAttribute(type);
/*  459: 455 */    if (attr == null) {
/*  460: 456 */      return null;
/*  461:     */    }
/*  462: 458 */    return attr.getAttributeValue();
/*  463:     */  }
/*  464:     */  
/*  469:     */  public List<VendorSpecificAttribute> getVendorAttributes(int vendorId)
/*  470:     */  {
/*  471: 467 */    LinkedList<VendorSpecificAttribute> result = new LinkedList();
/*  472: 468 */    for (Iterator<RadiusAttribute> i = this.attributes.iterator(); i.hasNext();) {
/*  473: 469 */      RadiusAttribute a = (RadiusAttribute)i.next();
/*  474: 470 */      if ((a instanceof VendorSpecificAttribute)) {
/*  475: 471 */        VendorSpecificAttribute vsa = (VendorSpecificAttribute)a;
/*  476: 472 */        if (vsa.getChildVendorId() == vendorId)
/*  477: 473 */          result.add(vsa);
/*  478:     */      }
/*  479:     */    }
/*  480: 476 */    return result;
/*  481:     */  }
/*  482:     */  
/*  489:     */  /**
/*  490:     */   * @deprecated
/*  491:     */   */
/*  492:     */  public VendorSpecificAttribute getVendorAttribute(int vendorId)
/*  493:     */  {
/*  494: 490 */    for (Iterator<RadiusAttribute> i = getAttributes(26).iterator(); i.hasNext();) {
/*  495: 491 */      RadiusAttribute ra = (RadiusAttribute)i.next();
/*  496: 492 */      if ((ra instanceof VendorSpecificAttribute)) {
/*  497: 493 */        VendorSpecificAttribute vsa = (VendorSpecificAttribute)ra;
/*  498: 494 */        if (vsa.getChildVendorId() == vendorId)
/*  499: 495 */          return vsa;
/*  500:     */      }
/*  501:     */    }
/*  502: 498 */    return null;
/*  503:     */  }
/*  504:     */  
/*  511:     */  public void encodeRequestPacket(OutputStream out, String sharedSecret)
/*  512:     */    throws IOException
/*  513:     */  {
/*  514: 510 */    encodePacket(out, sharedSecret, null);
/*  515:     */  }
/*  516:     */  
/*  524:     */  public void encodeResponsePacket(OutputStream out, String sharedSecret, RadiusPacket request)
/*  525:     */    throws IOException
/*  526:     */  {
/*  527: 523 */    if (request == null)
/*  528: 524 */      throw new NullPointerException("request cannot be null");
/*  529: 525 */    encodePacket(out, sharedSecret, request);
/*  530:     */  }
/*  531:     */  
/*  541:     */  public static RadiusPacket decodeRequestPacket(InputStream in, String sharedSecret)
/*  542:     */    throws IOException, RadiusException
/*  543:     */  {
/*  544: 540 */    return decodePacket(DefaultDictionary.getDefaultDictionary(), in, sharedSecret, null);
/*  545:     */  }
/*  546:     */  
/*  557:     */  public static RadiusPacket decodeResponsePacket(InputStream in, String sharedSecret, RadiusPacket request)
/*  558:     */    throws IOException, RadiusException
/*  559:     */  {
/*  560: 556 */    if (request == null)
/*  561: 557 */      throw new NullPointerException("request may not be null");
/*  562: 558 */    return decodePacket(DefaultDictionary.getDefaultDictionary(), in, sharedSecret, request);
/*  563:     */  }
/*  564:     */  
/*  576:     */  public static RadiusPacket decodeRequestPacket(Dictionary dictionary, InputStream in, String sharedSecret)
/*  577:     */    throws IOException, RadiusException
/*  578:     */  {
/*  579: 575 */    return decodePacket(dictionary, in, sharedSecret, null);
/*  580:     */  }
/*  581:     */  
/*  594:     */  public static RadiusPacket decodeResponsePacket(Dictionary dictionary, InputStream in, String sharedSecret, RadiusPacket request)
/*  595:     */    throws IOException, RadiusException
/*  596:     */  {
/*  597: 593 */    if (request == null)
/*  598: 594 */      throw new NullPointerException("request may not be null");
/*  599: 595 */    return decodePacket(dictionary, in, sharedSecret, request);
/*  600:     */  }
/*  601:     */  
/*  606:     */  public static synchronized int getNextPacketIdentifier()
/*  607:     */  {
/*  608: 604 */    nextPacketId += 1;
/*  609: 605 */    if (nextPacketId > 255)
/*  610: 606 */      nextPacketId = 0;
/*  611: 607 */    return nextPacketId;
/*  612:     */  }
/*  613:     */  
/*  615:     */  public static RadiusPacket createRadiusPacket(int type)
/*  616:     */  {
/*  617:     */    RadiusPacket rp;
/*  618:     */    
/*  619:     */    RadiusPacket rp;
/*  620:     */    
/*  621:     */    RadiusPacket rp;
/*  622:     */    
/*  623: 619 */    switch (type) {
/*  624:     */    case 1: 
/*  625: 621 */      rp = new AccessRequest();
/*  626: 622 */      break;
/*  627:     */    
/*  628:     */    case 4: 
/*  629: 625 */      rp = new AccountingRequest();
/*  630: 626 */      break;
/*  631:     */    
/*  632:     */    case 2: 
/*  633:     */    case 3: 
/*  634:     */    case 5: 
/*  635:     */    default: 
/*  636: 632 */      rp = new RadiusPacket();
/*  637:     */    }
/*  638:     */    
/*  639: 635 */    rp.setPacketType(type);
/*  640: 636 */    return rp;
/*  641:     */  }
/*  642:     */  
/*  646:     */  public String toString()
/*  647:     */  {
/*  648: 644 */    StringBuffer s = new StringBuffer();
/*  649: 645 */    s.append(getPacketTypeName());
/*  650: 646 */    s.append(", ID ");
/*  651: 647 */    s.append(this.packetIdentifier);
/*  652: 648 */    for (Iterator<RadiusAttribute> i = this.attributes.iterator(); i.hasNext();) {
/*  653: 649 */      RadiusAttribute attr = (RadiusAttribute)i.next();
/*  654: 650 */      s.append("\n");
/*  655: 651 */      s.append(attr.toString());
/*  656:     */    }
/*  657: 653 */    return s.toString();
/*  658:     */  }
/*  659:     */  
/*  668:     */  public byte[] getAuthenticator()
/*  669:     */  {
/*  670: 666 */    return this.authenticator;
/*  671:     */  }
/*  672:     */  
/*  678:     */  public void setAuthenticator(byte[] authenticator)
/*  679:     */  {
/*  680: 676 */    this.authenticator = authenticator;
/*  681:     */  }
/*  682:     */  
/*  686:     */  public Dictionary getDictionary()
/*  687:     */  {
/*  688: 684 */    return this.dictionary;
/*  689:     */  }
/*  690:     */  
/*  697:     */  public void setDictionary(Dictionary dictionary)
/*  698:     */  {
/*  699: 695 */    this.dictionary = dictionary;
/*  700: 696 */    for (Iterator<RadiusAttribute> i = this.attributes.iterator(); i.hasNext();) {
/*  701: 697 */      RadiusAttribute attr = (RadiusAttribute)i.next();
/*  702: 698 */      attr.setDictionary(dictionary);
/*  703:     */    }
/*  704:     */  }
/*  705:     */  
/*  716:     */  protected void encodePacket(OutputStream out, String sharedSecret, RadiusPacket request)
/*  717:     */    throws IOException
/*  718:     */  {
/*  719: 715 */    if ((sharedSecret == null) || (sharedSecret.length() == 0)) {
/*  720: 716 */      throw new RuntimeException("no shared secret has been set");
/*  721:     */    }
/*  722:     */    
/*  723: 719 */    if ((request != null) && (request.getAuthenticator() == null)) {
/*  724: 720 */      throw new RuntimeException("request authenticator not set");
/*  725:     */    }
/*  726:     */    
/*  727: 723 */    if (request == null)
/*  728:     */    {
/*  730: 726 */      this.authenticator = createRequestAuthenticator(sharedSecret);
/*  731: 727 */      encodeRequestAttributes(sharedSecret);
/*  732:     */    }
/*  733:     */    
/*  734: 730 */    byte[] attributes = getAttributeBytes();
/*  735: 731 */    int packetLength = 20 + attributes.length;
/*  736: 732 */    if (packetLength > 4096) {
/*  737: 733 */      throw new RuntimeException("packet too long");
/*  738:     */    }
/*  739:     */    
/*  740: 736 */    if (request != null)
/*  741:     */    {
/*  742: 738 */      this.authenticator = createResponseAuthenticator(sharedSecret, packetLength, attributes, request.getAuthenticator());
/*  743:     */    }
/*  744:     */    else {
/*  745: 741 */      this.authenticator = updateRequestAuthenticator(sharedSecret, packetLength, attributes);
/*  746:     */    }
/*  747:     */    
/*  748: 744 */    DataOutputStream dos = new DataOutputStream(out);
/*  749: 745 */    dos.writeByte(getPacketType());
/*  750: 746 */    dos.writeByte(getPacketIdentifier());
/*  751: 747 */    dos.writeShort(packetLength);
/*  752: 748 */    dos.write(getAuthenticator());
/*  753: 749 */    dos.write(attributes);
/*  754: 750 */    dos.flush();
/*  755:     */  }
/*  756:     */  
/*  764:     */  protected void encodeRequestAttributes(String sharedSecret) {}
/*  765:     */  
/*  773:     */  protected byte[] createRequestAuthenticator(String sharedSecret)
/*  774:     */  {
/*  775: 771 */    byte[] secretBytes = RadiusUtil.getUtf8Bytes(sharedSecret);
/*  776: 772 */    byte[] randomBytes = new byte[16];
/*  777: 773 */    random.nextBytes(randomBytes);
/*  778:     */    
/*  779: 775 */    MessageDigest md5 = getMd5Digest();
/*  780: 776 */    md5.reset();
/*  781: 777 */    md5.update(secretBytes);
/*  782: 778 */    md5.update(randomBytes);
/*  783: 779 */    return md5.digest();
/*  784:     */  }
/*  785:     */  
/*  793:     */  protected byte[] updateRequestAuthenticator(String sharedSecret, int packetLength, byte[] attributes)
/*  794:     */  {
/*  795: 791 */    return this.authenticator;
/*  796:     */  }
/*  797:     */  
/*  805:     */  protected byte[] createResponseAuthenticator(String sharedSecret, int packetLength, byte[] attributes, byte[] requestAuthenticator)
/*  806:     */  {
/*  807: 803 */    MessageDigest md5 = getMd5Digest();
/*  808: 804 */    md5.reset();
/*  809: 805 */    md5.update((byte)getPacketType());
/*  810: 806 */    md5.update((byte)getPacketIdentifier());
/*  811: 807 */    md5.update((byte)(packetLength >> 8));
/*  812: 808 */    md5.update((byte)(packetLength & 0xFF));
/*  813: 809 */    md5.update(requestAuthenticator, 0, requestAuthenticator.length);
/*  814: 810 */    md5.update(attributes, 0, attributes.length);
/*  815: 811 */    md5.update(RadiusUtil.getUtf8Bytes(sharedSecret));
/*  816: 812 */    return md5.digest();
/*  817:     */  }
/*  818:     */  
/*  832:     */  protected static RadiusPacket decodePacket(Dictionary dictionary, InputStream in, String sharedSecret, RadiusPacket request)
/*  833:     */    throws IOException, RadiusException
/*  834:     */  {
/*  835: 831 */    if ((sharedSecret == null) || (sharedSecret.length() == 0)) {
/*  836: 832 */      throw new RuntimeException("no shared secret has been set");
/*  837:     */    }
/*  838:     */    
/*  839: 835 */    if ((request != null) && (request.getAuthenticator() == null)) {
/*  840: 836 */      throw new RuntimeException("request authenticator not set");
/*  841:     */    }
/*  842:     */    
/*  843: 839 */    int type = in.read() & 0xFF;
/*  844: 840 */    int identifier = in.read() & 0xFF;
/*  845: 841 */    int length = (in.read() & 0xFF) << 8 | in.read() & 0xFF;
/*  846:     */    
/*  847: 843 */    if ((request != null) && (request.getPacketIdentifier() != identifier))
/*  848: 844 */      throw new RadiusException("bad packet: invalid packet identifier (request: " + request.getPacketIdentifier() + ", response: " + identifier);
/*  849: 845 */    if (length < 20)
/*  850: 846 */      throw new RadiusException("bad packet: packet too short (" + length + " bytes)");
/*  851: 847 */    if (length > 4096) {
/*  852: 848 */      throw new RadiusException("bad packet: packet too long (" + length + " bytes)");
/*  853:     */    }
/*  854:     */    
/*  855: 851 */    byte[] authenticator = new byte[16];
/*  856: 852 */    byte[] attributeData = new byte[length - 20];
/*  857: 853 */    in.read(authenticator);
/*  858: 854 */    in.read(attributeData);
/*  859:     */    
/*  861: 857 */    int pos = 0;
/*  862: 858 */    int attributeCount = 0;
/*  863: 859 */    while (pos < attributeData.length) {
/*  864: 860 */      if (pos + 1 >= attributeData.length)
/*  865: 861 */        throw new RadiusException("bad packet: attribute length mismatch");
/*  866: 862 */      int attributeLength = attributeData[(pos + 1)] & 0xFF;
/*  867: 863 */      if (attributeLength < 2)
/*  868: 864 */        throw new RadiusException("bad packet: invalid attribute length");
/*  869: 865 */      pos += attributeLength;
/*  870: 866 */      attributeCount++;
/*  871:     */    }
/*  872: 868 */    if (pos != attributeData.length) {
/*  873: 869 */      throw new RadiusException("bad packet: attribute length mismatch");
/*  874:     */    }
/*  875:     */    
/*  876: 872 */    RadiusPacket rp = createRadiusPacket(type);
/*  877: 873 */    rp.setPacketType(type);
/*  878: 874 */    rp.setPacketIdentifier(identifier);
/*  879: 875 */    rp.authenticator = authenticator;
/*  880:     */    
/*  882: 878 */    pos = 0;
/*  883: 879 */    while (pos < attributeData.length) {
/*  884: 880 */      int attributeType = attributeData[pos] & 0xFF;
/*  885: 881 */      int attributeLength = attributeData[(pos + 1)] & 0xFF;
/*  886: 882 */      RadiusAttribute a = RadiusAttribute.createRadiusAttribute(dictionary, -1, attributeType);
/*  887: 883 */      a.readAttribute(attributeData, pos, attributeLength);
/*  888: 884 */      rp.addAttribute(a);
/*  889: 885 */      pos += attributeLength;
/*  890:     */    }
/*  891:     */    
/*  893: 889 */    if (request == null)
/*  894:     */    {
/*  895: 891 */      rp.decodeRequestAttributes(sharedSecret);
/*  896: 892 */      rp.checkRequestAuthenticator(sharedSecret, length, attributeData);
/*  897:     */    }
/*  898:     */    else {
/*  899: 895 */      rp.checkResponseAuthenticator(sharedSecret, length, attributeData, request.getAuthenticator());
/*  900:     */    }
/*  901:     */    
/*  902: 898 */    return rp;
/*  903:     */  }
/*  904:     */  
/*  913:     */  protected void checkRequestAuthenticator(String sharedSecret, int packetLength, byte[] attributes)
/*  914:     */    throws RadiusException
/*  915:     */  {}
/*  916:     */  
/*  925:     */  protected void decodeRequestAttributes(String sharedSecret)
/*  926:     */    throws RadiusException
/*  927:     */  {}
/*  928:     */  
/*  936:     */  protected void checkResponseAuthenticator(String sharedSecret, int packetLength, byte[] attributes, byte[] requestAuthenticator)
/*  937:     */    throws RadiusException
/*  938:     */  {
/*  939: 935 */    byte[] authenticator = createResponseAuthenticator(sharedSecret, packetLength, attributes, requestAuthenticator);
/*  940: 936 */    byte[] receivedAuth = getAuthenticator();
/*  941: 937 */    for (int i = 0; i < 16; i++) {
/*  942: 938 */      if (authenticator[i] != receivedAuth[i]) {
/*  943: 939 */        throw new RadiusException("response authenticator invalid");
/*  944:     */      }
/*  945:     */    }
/*  946:     */  }
/*  947:     */  
/*  949:     */  protected MessageDigest getMd5Digest()
/*  950:     */  {
/*  951: 947 */    if (this.md5Digest == null)
/*  952:     */      try {
/*  953: 949 */        this.md5Digest = MessageDigest.getInstance("MD5");
/*  954:     */      } catch (NoSuchAlgorithmException nsae) {
/*  955: 951 */        throw new RuntimeException("md5 digest not available", nsae);
/*  956:     */      }
/*  957: 953 */    return this.md5Digest;
/*  958:     */  }
/*  959:     */  
/*  964:     */  protected byte[] getAttributeBytes()
/*  965:     */    throws IOException
/*  966:     */  {
/*  967: 963 */    ByteArrayOutputStream bos = new ByteArrayOutputStream(4096);
/*  968: 964 */    for (Iterator<RadiusAttribute> i = this.attributes.iterator(); i.hasNext();) {
/*  969: 965 */      RadiusAttribute a = (RadiusAttribute)i.next();
/*  970: 966 */      bos.write(a.writeAttribute());
/*  971:     */    }
/*  972: 968 */    bos.flush();
/*  973: 969 */    return bos.toByteArray();
/*  974:     */  }
/*  975:     */  
/*  979: 975 */  private int packetType = 0;
/*  980:     */  
/*  984: 980 */  private int packetIdentifier = 0;
/*  985:     */  
/*  989: 985 */  private List<RadiusAttribute> attributes = new ArrayList();
/*  990:     */  
/*  994: 990 */  private MessageDigest md5Digest = null;
/*  995:     */  
/*  999: 995 */  private byte[] authenticator = null;
/* 1000:     */  
/* 1004:1000 */  private Dictionary dictionary = DefaultDictionary.getDefaultDictionary();
/* 1005:     */  
/* 1009:1005 */  private static int nextPacketId = 0;
/* 1010:     */  
/* 1014:1010 */  private static SecureRandom random = new SecureRandom();
/* 1015:     */}


/* Location:           D:\cache\windows\Desktop\radius-server-1.0\
 * Qualified Name:     com.radius.server.packet.RadiusPacket
 * JD-Core Version:    0.7.0-SNAPSHOT-20130630
 */