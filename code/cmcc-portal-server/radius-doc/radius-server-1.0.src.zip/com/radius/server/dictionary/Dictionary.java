package com.radius.server.dictionary;

public abstract interface Dictionary
{
  public abstract AttributeType getAttributeTypeByName(String paramString);
  
  public abstract AttributeType getAttributeTypeByCode(int paramInt);
  
  public abstract AttributeType getAttributeTypeByCode(int paramInt1, int paramInt2);
  
  public abstract String getVendorName(int paramInt);
  
  public abstract int getVendorId(String paramString);
}


/* Location:           D:\cache\windows\Desktop\radius-server-1.0\
 * Qualified Name:     com.radius.server.dictionary.Dictionary
 * JD-Core Version:    0.7.0-SNAPSHOT-20130630
 */