/*  1:   */package com.radius.server.test;
/*  2:   */
/*  3:   */import com.radius.server.attribute.IpAttribute;
/*  4:   */import com.radius.server.dictionary.Dictionary;
/*  5:   */import com.radius.server.dictionary.DictionaryParser;
/*  6:   */import com.radius.server.packet.AccessRequest;
/*  7:   */import java.io.FileInputStream;
/*  8:   */import java.io.InputStream;
/*  9:   */import java.io.PrintStream;
/* 10:   */
/* 21:   */public class TestDictionary
/* 22:   */{
/* 23:   */  public static void main(String[] args)
/* 24:   */    throws Exception
/* 25:   */  {
/* 26:26 */    InputStream source = new FileInputStream("test.dictionary");
/* 27:27 */    Dictionary dictionary = DictionaryParser.parseDictionary("", source);
/* 28:28 */    AccessRequest ar = new AccessRequest("UserName", "UserPassword");
/* 29:29 */    ar.setDictionary(dictionary);
/* 30:30 */    ar.addAttribute("WISPr-Location-ID", "LocationID");
/* 31:31 */    ar.addAttribute(new IpAttribute(8, 1234567L));
/* 32:32 */    System.out.println(ar);
/* 33:   */  }
/* 34:   */}


/* Location:           D:\cache\windows\Desktop\radius-server-1.0\
 * Qualified Name:     com.radius.server.test.TestDictionary
 * JD-Core Version:    0.7.0-SNAPSHOT-20130630
 */