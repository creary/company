/*   1:    */package com.radius.server.util;
/*   2:    */
/*   3:    */import com.radius.server.attribute.RadiusAttribute;
/*   4:    */import com.radius.server.packet.AccessRequest;
/*   5:    */import com.radius.server.packet.AccountingRequest;
/*   6:    */import com.radius.server.packet.RadiusPacket;
/*   7:    */import java.io.ByteArrayInputStream;
/*   8:    */import java.io.ByteArrayOutputStream;
/*   9:    */import java.io.IOException;
/*  10:    */import java.net.DatagramPacket;
/*  11:    */import java.net.DatagramSocket;
/*  12:    */import java.net.InetAddress;
/*  13:    */import java.net.InetSocketAddress;
/*  14:    */import java.net.SocketException;
/*  15:    */import java.net.SocketTimeoutException;
/*  16:    */import java.util.Arrays;
/*  17:    */import java.util.Iterator;
/*  18:    */import java.util.LinkedList;
/*  19:    */import java.util.List;
/*  20:    */import org.apache.log4j.Logger;
/*  21:    */
/*  56:    */public abstract class RadiusServer
/*  57:    */{
/*  58:    */  public abstract String getSharedSecret(InetSocketAddress paramInetSocketAddress);
/*  59:    */  
/*  60:    */  public abstract String getUserPassword(String paramString);
/*  61:    */  
/*  62:    */  public RadiusPacket accessRequestReceived(AccessRequest accessRequest, InetSocketAddress client)
/*  63:    */    throws RadiusException
/*  64:    */  {
/*  65: 65 */    String plaintext = getUserPassword(accessRequest.getUserName());
/*  66: 66 */    int type = 3;
/*  67: 67 */    if ((plaintext != null) && (accessRequest.verifyPassword(plaintext))) {
/*  68: 68 */      type = 2;
/*  69:    */    }
/*  70: 70 */    RadiusPacket answer = new RadiusPacket(type, accessRequest.getPacketIdentifier());
/*  71: 71 */    copyProxyState(accessRequest, answer);
/*  72: 72 */    return answer;
/*  73:    */  }
/*  74:    */  
/*  83:    */  public RadiusPacket accountingRequestReceived(AccountingRequest accountingRequest, InetSocketAddress client)
/*  84:    */    throws RadiusException
/*  85:    */  {
/*  86: 86 */    RadiusPacket answer = new RadiusPacket(5, accountingRequest.getPacketIdentifier());
/*  87: 87 */    copyProxyState(accountingRequest, answer);
/*  88: 88 */    return answer;
/*  89:    */  }
/*  90:    */  
/*  95:    */  public void start(boolean listenAuth, boolean listenAcct)
/*  96:    */  {
/*  97: 97 */    if (listenAuth)
/*  98:    */    {
/* 113:113 */      new Thread() {
/* 114:    */        public void run() {
/* 115:100 */          setName("Radius Auth Listener");
/* 116:    */          try {
/* 117:102 */            RadiusServer.logger.info("starting RadiusAuthListener on port " + RadiusServer.this.getAuthPort());
/* 118:103 */            RadiusServer.this.listenAuth();
/* 119:104 */            RadiusServer.logger.info("RadiusAuthListener is being terminated");
/* 120:    */          } catch (Exception e) {
/* 121:106 */            e.printStackTrace();
/* 122:107 */            RadiusServer.logger.fatal("auth thread stopped by exception", e);
/* 123:    */          } finally {
/* 124:109 */            RadiusServer.this.authSocket.close();
/* 125:110 */            RadiusServer.logger.debug("auth socket closed");
/* 126:    */          }
/* 127:    */        }
/* 128:    */      }.start();
/* 129:    */    }
/* 130:    */    
/* 131:116 */    if (listenAcct)
/* 132:    */    {
/* 147:132 */      new Thread() {
/* 148:    */        public void run() {
/* 149:119 */          setName("Radius Acct Listener");
/* 150:    */          try {
/* 151:121 */            RadiusServer.logger.info("starting RadiusAcctListener on port " + RadiusServer.this.getAcctPort());
/* 152:122 */            RadiusServer.this.listenAcct();
/* 153:123 */            RadiusServer.logger.info("RadiusAcctListener is being terminated");
/* 154:    */          } catch (Exception e) {
/* 155:125 */            e.printStackTrace();
/* 156:126 */            RadiusServer.logger.fatal("acct thread stopped by exception", e);
/* 157:    */          } finally {
/* 158:128 */            RadiusServer.this.acctSocket.close();
/* 159:129 */            RadiusServer.logger.debug("acct socket closed");
/* 160:    */          }
/* 161:    */        }
/* 162:    */      }.start();
/* 163:    */    }
/* 164:    */  }
/* 165:    */  
/* 168:    */  public void stop()
/* 169:    */  {
/* 170:140 */    logger.info("stopping Radius server");
/* 171:141 */    this.closing = true;
/* 172:142 */    if (this.authSocket != null)
/* 173:143 */      this.authSocket.close();
/* 174:144 */    if (this.acctSocket != null) {
/* 175:145 */      this.acctSocket.close();
/* 176:    */    }
/* 177:    */  }
/* 178:    */  
/* 181:    */  public int getAuthPort()
/* 182:    */  {
/* 183:153 */    return this.authPort;
/* 184:    */  }
/* 185:    */  
/* 189:    */  public void setAuthPort(int authPort)
/* 190:    */  {
/* 191:161 */    if ((authPort < 1) || (authPort > 65535))
/* 192:162 */      throw new IllegalArgumentException("bad port number");
/* 193:163 */    this.authPort = authPort;
/* 194:164 */    this.authSocket = null;
/* 195:    */  }
/* 196:    */  
/* 200:    */  public int getSocketTimeout()
/* 201:    */  {
/* 202:172 */    return this.socketTimeout;
/* 203:    */  }
/* 204:    */  
/* 209:    */  public void setSocketTimeout(int socketTimeout)
/* 210:    */    throws SocketException
/* 211:    */  {
/* 212:182 */    if (socketTimeout < 1)
/* 213:183 */      throw new IllegalArgumentException("socket tiemout must be positive");
/* 214:184 */    this.socketTimeout = socketTimeout;
/* 215:185 */    if (this.authSocket != null)
/* 216:186 */      this.authSocket.setSoTimeout(socketTimeout);
/* 217:187 */    if (this.acctSocket != null) {
/* 218:188 */      this.acctSocket.setSoTimeout(socketTimeout);
/* 219:    */    }
/* 220:    */  }
/* 221:    */  
/* 224:    */  public void setAcctPort(int acctPort)
/* 225:    */  {
/* 226:196 */    if ((acctPort < 1) || (acctPort > 65535))
/* 227:197 */      throw new IllegalArgumentException("bad port number");
/* 228:198 */    this.acctPort = acctPort;
/* 229:199 */    this.acctSocket = null;
/* 230:    */  }
/* 231:    */  
/* 235:    */  public int getAcctPort()
/* 236:    */  {
/* 237:207 */    return this.acctPort;
/* 238:    */  }
/* 239:    */  
/* 246:    */  public long getDuplicateInterval()
/* 247:    */  {
/* 248:218 */    return this.duplicateInterval;
/* 249:    */  }
/* 250:    */  
/* 257:    */  public void setDuplicateInterval(long duplicateInterval)
/* 258:    */  {
/* 259:229 */    if (duplicateInterval <= 0L)
/* 260:230 */      throw new IllegalArgumentException("duplicate interval must be positive");
/* 261:231 */    this.duplicateInterval = duplicateInterval;
/* 262:    */  }
/* 263:    */  
/* 268:    */  public InetAddress getListenAddress()
/* 269:    */  {
/* 270:240 */    return this.listenAddress;
/* 271:    */  }
/* 272:    */  
/* 279:    */  public void setListenAddress(InetAddress listenAddress)
/* 280:    */  {
/* 281:251 */    this.listenAddress = listenAddress;
/* 282:    */  }
/* 283:    */  
/* 289:    */  protected void copyProxyState(RadiusPacket request, RadiusPacket answer)
/* 290:    */  {
/* 291:261 */    List<RadiusAttribute> proxyStateAttrs = request.getAttributes(33);
/* 292:262 */    for (Iterator<RadiusAttribute> i = proxyStateAttrs.iterator(); i.hasNext();) {
/* 293:263 */      RadiusAttribute proxyStateAttr = (RadiusAttribute)i.next();
/* 294:264 */      answer.addAttribute(proxyStateAttr);
/* 295:    */    }
/* 296:    */  }
/* 297:    */  
/* 304:    */  protected void listenAuth()
/* 305:    */    throws SocketException
/* 306:    */  {
/* 307:277 */    listen(getAuthSocket());
/* 308:    */  }
/* 309:    */  
/* 315:    */  protected void listenAcct()
/* 316:    */    throws SocketException
/* 317:    */  {
/* 318:288 */    listen(getAcctSocket());
/* 319:    */  }
/* 320:    */  
/* 324:    */  protected void listen(DatagramSocket s)
/* 325:    */  {
/* 326:296 */    DatagramPacket packetIn = new DatagramPacket(new byte[4096], 
/* 327:297 */      4096);
/* 328:    */    try
/* 329:    */    {
/* 330:    */      for (;;) {
/* 331:    */        try {
/* 332:302 */          logger.debug("about to call socket.receive()");
/* 333:303 */          s.receive(packetIn);
/* 334:304 */          if (!logger.isDebugEnabled()) break label95;
/* 335:305 */          logger.debug("receive buffer size = " + s.getReceiveBufferSize());
/* 336:    */        } catch (SocketException se) {
/* 337:307 */          if (this.closing)
/* 338:    */          {
/* 339:309 */            logger.info("got closing signal - end listen thread");
/* 340:310 */            return;
/* 341:    */          }
/* 342:    */          
/* 343:313 */          logger.warn("SocketException during s.receive() -> retry", se); }
/* 344:314 */        continue;
/* 345:    */        
/* 347:    */        label95:
/* 348:    */        
/* 349:319 */        InetSocketAddress localAddress = (InetSocketAddress)s.getLocalSocketAddress();
/* 350:320 */        InetSocketAddress remoteAddress = new InetSocketAddress(packetIn.getAddress(), packetIn.getPort());
/* 351:321 */        String secret = getSharedSecret(remoteAddress);
/* 352:322 */        if (secret == null) {
/* 353:323 */          if (logger.isInfoEnabled()) {
/* 354:324 */            logger.info("ignoring packet from unknown client " + 
/* 355:325 */              remoteAddress + " received on local address " + localAddress);
/* 356:    */          }
/* 357:    */        }
/* 358:    */        else
/* 359:    */        {
/* 360:330 */          RadiusPacket request = makeRadiusPacket(packetIn, secret);
/* 361:331 */          if (isDebugServer()) { logger.warn("debug information: \n" + request);
/* 362:    */          }
/* 363:333 */          logger.debug("about to call RadiusServer.handlePacket()");
/* 364:334 */          RadiusPacket response = handlePacket(localAddress, remoteAddress, request, secret);
/* 365:    */          
/* 367:337 */          if (response != null) {
/* 368:338 */            if (logger.isInfoEnabled()) {
/* 369:339 */              logger.info("send response: " + response);
/* 370:    */            }
/* 371:341 */            if (isDebugServer()) logger.warn("debug information: \n" + response);
/* 372:342 */            DatagramPacket packetOut = makeDatagramPacket(response, secret, 
/* 373:343 */              remoteAddress.getAddress(), packetIn.getPort(), request);
/* 374:344 */            s.send(packetOut);
/* 375:    */          } else {
/* 376:346 */            logger.info("no response sent");
/* 377:    */          }
/* 378:    */        }
/* 379:    */      }
/* 380:350 */    } catch (SocketTimeoutException ste) { for (;;) { logger.debug("normal socket timeout");
/* 381:    */      }
/* 382:    */    } catch (IOException ioe) {
/* 383:353 */      for (;;) { logger.warn("communication error", ioe);
/* 384:    */      }
/* 385:    */    } catch (RadiusException re) {
/* 386:356 */      for (;;) { logger.warn("malformed Radius packet", re);
/* 387:    */      }
/* 388:358 */    } catch (Throwable throwable) { logger.warn("system error Radius packet", throwable);
/* 389:    */    }
/* 390:    */  }
/* 391:    */  
/* 401:    */  protected RadiusPacket handlePacket(InetSocketAddress localAddress, InetSocketAddress remoteAddress, RadiusPacket request, String sharedSecret)
/* 402:    */    throws RadiusException, IOException
/* 403:    */  {
/* 404:374 */    RadiusPacket response = null;
/* 405:    */    
/* 407:377 */    if (!isPacketDuplicate(request, remoteAddress)) {
/* 408:378 */      if (localAddress.getPort() == getAuthPort())
/* 409:    */      {
/* 410:380 */        if ((request instanceof AccessRequest)) {
/* 411:381 */          response = accessRequestReceived((AccessRequest)request, remoteAddress);
/* 412:    */        } else
/* 413:383 */          logger.warn("unknown Radius packet type: " + request.getPacketType());
/* 414:384 */      } else if (localAddress.getPort() == getAcctPort())
/* 415:    */      {
/* 416:386 */        if ((request instanceof AccountingRequest)) {
/* 417:387 */          response = accountingRequestReceived((AccountingRequest)request, remoteAddress);
/* 418:    */        } else {
/* 419:389 */          logger.warn("unknown Radius packet type: " + request.getPacketType());
/* 420:    */        }
/* 421:    */      }
/* 422:    */    }
/* 423:    */    else {
/* 424:394 */      logger.info("ignore duplicate packet");
/* 425:    */    }
/* 426:396 */    return response;
/* 427:    */  }
/* 428:    */  
/* 433:    */  protected DatagramSocket getAuthSocket()
/* 434:    */    throws SocketException
/* 435:    */  {
/* 436:406 */    if (this.authSocket == null) {
/* 437:407 */      if (getListenAddress() == null) {
/* 438:408 */        this.authSocket = new DatagramSocket(getAuthPort());
/* 439:    */      } else
/* 440:410 */        this.authSocket = new DatagramSocket(getAuthPort(), getListenAddress());
/* 441:411 */      this.authSocket.setSoTimeout(getSocketTimeout());
/* 442:    */    }
/* 443:413 */    return this.authSocket;
/* 444:    */  }
/* 445:    */  
/* 450:    */  protected DatagramSocket getAcctSocket()
/* 451:    */    throws SocketException
/* 452:    */  {
/* 453:423 */    if (this.acctSocket == null) {
/* 454:424 */      if (getListenAddress() == null) {
/* 455:425 */        this.acctSocket = new DatagramSocket(getAcctPort());
/* 456:    */      } else
/* 457:427 */        this.acctSocket = new DatagramSocket(getAcctPort(), getListenAddress());
/* 458:428 */      this.acctSocket.setSoTimeout(getSocketTimeout());
/* 459:    */    }
/* 460:430 */    return this.acctSocket;
/* 461:    */  }
/* 462:    */  
/* 473:    */  protected DatagramPacket makeDatagramPacket(RadiusPacket packet, String secret, InetAddress address, int port, RadiusPacket request)
/* 474:    */    throws IOException
/* 475:    */  {
/* 476:446 */    ByteArrayOutputStream bos = new ByteArrayOutputStream();
/* 477:447 */    packet.encodeResponsePacket(bos, secret, request);
/* 478:448 */    byte[] data = bos.toByteArray();
/* 479:    */    
/* 480:450 */    DatagramPacket datagram = new DatagramPacket(data, data.length, address, port);
/* 481:451 */    return datagram;
/* 482:    */  }
/* 483:    */  
/* 492:    */  protected RadiusPacket makeRadiusPacket(DatagramPacket packet, String sharedSecret)
/* 493:    */    throws IOException, RadiusException
/* 494:    */  {
/* 495:465 */    ByteArrayInputStream in = new ByteArrayInputStream(packet.getData());
/* 496:466 */    return RadiusPacket.decodeRequestPacket(in, sharedSecret);
/* 497:    */  }
/* 498:    */  
/* 506:    */  protected boolean isPacketDuplicate(RadiusPacket packet, InetSocketAddress address)
/* 507:    */  {
/* 508:478 */    long now = System.currentTimeMillis();
/* 509:479 */    long intervalStart = now - getDuplicateInterval();
/* 510:    */    
/* 511:481 */    byte[] authenticator = packet.getAuthenticator();
/* 512:    */    
/* 513:483 */    synchronized (this.receivedPackets) {
/* 514:484 */      for (Iterator<ReceivedPacket> i = this.receivedPackets.iterator(); i.hasNext();) {
/* 515:485 */        ReceivedPacket p = (ReceivedPacket)i.next();
/* 516:486 */        if (p.receiveTime < intervalStart)
/* 517:    */        {
/* 518:488 */          i.remove();
/* 519:    */        }
/* 520:490 */        else if ((p.address.equals(address)) && (p.packetIdentifier == packet.getPacketIdentifier())) {
/* 521:491 */          if ((authenticator != null) && (p.authenticator != null))
/* 522:    */          {
/* 524:494 */            return Arrays.equals(p.authenticator, authenticator);
/* 525:    */          }
/* 526:    */          
/* 527:497 */          return true;
/* 528:    */        }
/* 529:    */      }
/* 530:    */      
/* 534:504 */      ReceivedPacket rp = new ReceivedPacket();
/* 535:505 */      rp.address = address;
/* 536:506 */      rp.packetIdentifier = packet.getPacketIdentifier();
/* 537:507 */      rp.receiveTime = now;
/* 538:508 */      rp.authenticator = authenticator;
/* 539:509 */      this.receivedPackets.add(rp);
/* 540:    */    }
/* 541:    */    
/* 542:512 */    return false;
/* 543:    */  }
/* 544:    */  
/* 545:    */  protected boolean isDebugServer() {
/* 546:516 */    return true;
/* 547:    */  }
/* 548:    */  
/* 549:    */  public RadiusServer() {}
/* 550:    */  
/* 551:    */  public RadiusServer(int authPort, int acctPort)
/* 552:    */  {
/* 553:523 */    this.acctPort = acctPort;
/* 554:524 */    this.authPort = authPort;
/* 555:    */  }
/* 556:    */  
/* 558:528 */  private InetAddress listenAddress = null;
/* 559:529 */  private int authPort = 1812;
/* 560:530 */  private int acctPort = 1813;
/* 561:531 */  private DatagramSocket authSocket = null;
/* 562:532 */  private DatagramSocket acctSocket = null;
/* 563:533 */  private int socketTimeout = 3000;
/* 564:534 */  private List<ReceivedPacket> receivedPackets = new LinkedList();
/* 565:535 */  private long duplicateInterval = 30000L;
/* 566:536 */  private boolean closing = false;
/* 567:537 */  private static Logger logger = Logger.getLogger(RadiusServer.class);
/* 568:    */}


/* Location:           D:\cache\windows\Desktop\radius-server-1.0\
 * Qualified Name:     com.radius.server.util.RadiusServer
 * JD-Core Version:    0.7.0-SNAPSHOT-20130630
 */