/*  1:   */package com.radius.server.test;
/*  2:   */
/*  3:   */import com.radius.server.packet.AccountingRequest;
/*  4:   */import com.radius.server.packet.RadiusPacket;
/*  5:   */import com.radius.server.proxy.RadiusProxy;
/*  6:   */import com.radius.server.util.RadiusEndpoint;
/*  7:   */import java.net.InetAddress;
/*  8:   */import java.net.InetSocketAddress;
/*  9:   */import java.net.UnknownHostException;
/* 10:   */
/* 27:   */public class TestProxy
/* 28:   */  extends RadiusProxy
/* 29:   */{
/* 30:   */  public RadiusEndpoint getProxyServer(RadiusPacket packet, RadiusEndpoint client)
/* 31:   */  {
/* 32:   */    try
/* 33:   */    {
/* 34:34 */      InetAddress address = InetAddress.getByAddress(new byte[] { 127, 0, 0, 1 });
/* 35:35 */      int port = 10000;
/* 36:36 */      if ((packet instanceof AccountingRequest))
/* 37:37 */        port = 10001;
/* 38:38 */      return new RadiusEndpoint(new InetSocketAddress(address, port), "testing123");
/* 39:   */    } catch (UnknownHostException uhe) {
/* 40:40 */      uhe.printStackTrace(); }
/* 41:41 */    return null;
/* 42:   */  }
/* 43:   */  
/* 44:   */  public String getSharedSecret(InetSocketAddress client)
/* 45:   */  {
/* 46:46 */    if ((client.getPort() == 10000) || (client.getPort() == 10001))
/* 47:47 */      return "testing123";
/* 48:48 */    if (client.getAddress().getHostAddress().equals("127.0.0.1")) {
/* 49:49 */      return "proxytest";
/* 50:   */    }
/* 51:51 */    return null;
/* 52:   */  }
/* 53:   */  
/* 54:   */  public String getUserPassword(String userName)
/* 55:   */  {
/* 56:56 */    return null;
/* 57:   */  }
/* 58:   */  
/* 59:   */  public static void main(String[] args) {
/* 60:60 */    new TestProxy().start(true, true, true);
/* 61:   */  }
/* 62:   */}


/* Location:           D:\cache\windows\Desktop\radius-server-1.0\
 * Qualified Name:     com.radius.server.test.TestProxy
 * JD-Core Version:    0.7.0-SNAPSHOT-20130630
 */