package com.radius.server.dictionary;

public abstract interface WritableDictionary
  extends Dictionary
{
  public abstract void addVendor(int paramInt, String paramString);
  
  public abstract void addAttributeType(AttributeType paramAttributeType);
}


/* Location:           D:\cache\windows\Desktop\radius-server-1.0\
 * Qualified Name:     com.radius.server.dictionary.WritableDictionary
 * JD-Core Version:    0.7.0-SNAPSHOT-20130630
 */