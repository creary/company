/*   1:    */package com.radius.server.dictionary;
/*   2:    */
/*   3:    */import com.radius.server.attribute.RadiusAttribute;
/*   4:    */import java.util.HashMap;
/*   5:    */import java.util.Iterator;
/*   6:    */import java.util.Map;
/*   7:    */import java.util.Map.Entry;
/*   8:    */import java.util.Set;
/*   9:    */
/*  28:    */public class AttributeType
/*  29:    */{
/*  30:    */  public AttributeType(int code, String name, Class<?> type)
/*  31:    */  {
/*  32: 32 */    setTypeCode(code);
/*  33: 33 */    setName(name);
/*  34: 34 */    setAttributeClass(type);
/*  35:    */  }
/*  36:    */  
/*  43:    */  public AttributeType(int vendor, int code, String name, Class<?> type)
/*  44:    */  {
/*  45: 45 */    setTypeCode(code);
/*  46: 46 */    setName(name);
/*  47: 47 */    setAttributeClass(type);
/*  48: 48 */    setVendorId(vendor);
/*  49:    */  }
/*  50:    */  
/*  54:    */  public int getTypeCode()
/*  55:    */  {
/*  56: 56 */    return this.typeCode;
/*  57:    */  }
/*  58:    */  
/*  62:    */  public void setTypeCode(int code)
/*  63:    */  {
/*  64: 64 */    if ((code < 1) || (code > 255))
/*  65: 65 */      throw new IllegalArgumentException("code out of bounds");
/*  66: 66 */    this.typeCode = code;
/*  67:    */  }
/*  68:    */  
/*  72:    */  public String getName()
/*  73:    */  {
/*  74: 74 */    return this.name;
/*  75:    */  }
/*  76:    */  
/*  80:    */  public void setName(String name)
/*  81:    */  {
/*  82: 82 */    if ((name == null) || (name.length() == 0))
/*  83: 83 */      throw new IllegalArgumentException("name is empty");
/*  84: 84 */    this.name = name;
/*  85:    */  }
/*  86:    */  
/*  91:    */  public Class<?> getAttributeClass()
/*  92:    */  {
/*  93: 93 */    return this.attributeClass;
/*  94:    */  }
/*  95:    */  
/*  99:    */  public void setAttributeClass(Class<?> type)
/* 100:    */  {
/* 101:101 */    if (type == null)
/* 102:102 */      throw new NullPointerException("type is null");
/* 103:103 */    if (!RadiusAttribute.class.isAssignableFrom(type))
/* 104:104 */      throw new IllegalArgumentException("type is not a RadiusAttribute descendant");
/* 105:105 */    this.attributeClass = type;
/* 106:    */  }
/* 107:    */  
/* 112:    */  public int getVendorId()
/* 113:    */  {
/* 114:114 */    return this.vendorId;
/* 115:    */  }
/* 116:    */  
/* 120:    */  public void setVendorId(int vendorId)
/* 121:    */  {
/* 122:122 */    this.vendorId = vendorId;
/* 123:    */  }
/* 124:    */  
/* 130:    */  public String getEnumeration(int value)
/* 131:    */  {
/* 132:132 */    if (this.enumeration != null) {
/* 133:133 */      return (String)this.enumeration.get(new Integer(value));
/* 134:    */    }
/* 135:135 */    return null;
/* 136:    */  }
/* 137:    */  
/* 144:    */  public Integer getEnumeration(String value)
/* 145:    */  {
/* 146:146 */    if ((value == null) || (value.length() == 0))
/* 147:147 */      throw new IllegalArgumentException("value is empty");
/* 148:148 */    if (this.enumeration == null)
/* 149:149 */      return null;
/* 150:150 */    for (Iterator i = this.enumeration.entrySet().iterator(); i.hasNext();) {
/* 151:151 */      Map.Entry e = (Map.Entry)i.next();
/* 152:152 */      if (e.getValue().equals(value))
/* 153:153 */        return (Integer)e.getKey();
/* 154:    */    }
/* 155:155 */    return null;
/* 156:    */  }
/* 157:    */  
/* 162:    */  public void addEnumerationValue(int num, String name)
/* 163:    */  {
/* 164:164 */    if ((name == null) || (name.length() == 0))
/* 165:165 */      throw new IllegalArgumentException("name is empty");
/* 166:166 */    if (this.enumeration == null)
/* 167:167 */      this.enumeration = new HashMap();
/* 168:168 */    this.enumeration.put(new Integer(num), name);
/* 169:    */  }
/* 170:    */  
/* 176:    */  public String toString()
/* 177:    */  {
/* 178:178 */    String s = getTypeCode() + 
/* 179:179 */      "/" + getName() + 
/* 180:180 */      ": " + this.attributeClass.getName();
/* 181:181 */    if (getVendorId() != -1)
/* 182:182 */      s = s + " (vendor " + getVendorId() + ")";
/* 183:183 */    return s;
/* 184:    */  }
/* 185:    */  
/* 186:186 */  private int vendorId = -1;
/* 187:    */  private int typeCode;
/* 188:    */  private String name;
/* 189:    */  private Class<?> attributeClass;
/* 190:190 */  private Map<Integer, String> enumeration = null;
/* 191:    */}


/* Location:           D:\cache\windows\Desktop\radius-server-1.0\
 * Qualified Name:     com.radius.server.dictionary.AttributeType
 * JD-Core Version:    0.7.0-SNAPSHOT-20130630
 */