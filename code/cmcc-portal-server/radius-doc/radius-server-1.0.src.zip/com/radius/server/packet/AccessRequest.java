/*   1:    */package com.radius.server.packet;
/*   2:    */
/*   3:    */import com.radius.server.attribute.RadiusAttribute;
/*   4:    */import com.radius.server.attribute.StringAttribute;
/*   5:    */import com.radius.server.util.RadiusException;
/*   6:    */import com.radius.server.util.RadiusUtil;
/*   7:    */import java.security.MessageDigest;
/*   8:    */import java.security.SecureRandom;
/*   9:    */import java.util.List;
/*  10:    */import org.apache.commons.logging.Log;
/*  11:    */import org.apache.commons.logging.LogFactory;
/*  12:    */
/*  40:    */public class AccessRequest
/*  41:    */  extends RadiusPacket
/*  42:    */{
/*  43:    */  public static final String AUTH_PAP = "pap";
/*  44:    */  public static final String AUTH_CHAP = "chap";
/*  45:    */  private String password;
/*  46:    */  
/*  47:    */  public AccessRequest() {}
/*  48:    */  
/*  49:    */  public AccessRequest(String userName, String userPassword)
/*  50:    */  {
/*  51: 51 */    super(1, getNextPacketIdentifier());
/*  52: 52 */    setUserName(userName);
/*  53: 53 */    setUserPassword(userPassword);
/*  54:    */  }
/*  55:    */  
/*  59:    */  public void setUserName(String userName)
/*  60:    */  {
/*  61: 61 */    if (userName == null)
/*  62: 62 */      throw new NullPointerException("user name not set");
/*  63: 63 */    if (userName.length() == 0) {
/*  64: 64 */      throw new IllegalArgumentException("empty user name not allowed");
/*  65:    */    }
/*  66: 66 */    removeAttributes(1);
/*  67: 67 */    addAttribute(new StringAttribute(1, userName));
/*  68:    */  }
/*  69:    */  
/*  73:    */  public void setUserPassword(String userPassword)
/*  74:    */  {
/*  75: 75 */    if ((userPassword == null) || (userPassword.length() == 0))
/*  76: 76 */      throw new IllegalArgumentException("password is empty");
/*  77: 77 */    this.password = userPassword;
/*  78:    */  }
/*  79:    */  
/*  85:    */  public String getUserPassword()
/*  86:    */  {
/*  87: 87 */    return this.password;
/*  88:    */  }
/*  89:    */  
/*  93:    */  public String getUserName()
/*  94:    */  {
/*  95: 95 */    List<RadiusAttribute> attrs = getAttributes(1);
/*  96: 96 */    if ((attrs.size() < 1) || (attrs.size() > 1)) {
/*  97: 97 */      throw new RuntimeException("exactly one User-Name attribute required");
/*  98:    */    }
/*  99: 99 */    RadiusAttribute ra = (RadiusAttribute)attrs.get(0);
/* 100:100 */    return ra.getAttributeValue();
/* 101:    */  }
/* 102:    */  
/* 106:    */  public String getAuthProtocol()
/* 107:    */  {
/* 108:108 */    return this.authProtocol;
/* 109:    */  }
/* 110:    */  
/* 115:    */  public void setAuthProtocol(String authProtocol)
/* 116:    */  {
/* 117:117 */    if ((authProtocol != null) && ((authProtocol.equals("pap")) || (authProtocol.equals("chap")))) {
/* 118:118 */      this.authProtocol = authProtocol;
/* 119:    */    } else {
/* 120:120 */      throw new IllegalArgumentException("protocol must be pap or chap");
/* 121:    */    }
/* 122:    */  }
/* 123:    */  
/* 129:    */  public boolean verifyPassword(String plaintext)
/* 130:    */    throws RadiusException
/* 131:    */  {
/* 132:132 */    if ((plaintext == null) || (plaintext.length() == 0))
/* 133:133 */      throw new IllegalArgumentException("password is empty");
/* 134:134 */    if (getAuthProtocol().equals("chap")) {
/* 135:135 */      return verifyChapPassword(plaintext);
/* 136:    */    }
/* 137:137 */    return getUserPassword().equals(plaintext);
/* 138:    */  }
/* 139:    */  
/* 144:    */  protected void decodeRequestAttributes(String sharedSecret)
/* 145:    */    throws RadiusException
/* 146:    */  {
/* 147:147 */    RadiusAttribute userPassword = getAttribute(2);
/* 148:148 */    RadiusAttribute chapPassword = getAttribute(3);
/* 149:149 */    RadiusAttribute chapChallenge = getAttribute(60);
/* 150:    */    
/* 151:151 */    if (userPassword != null) {
/* 152:152 */      setAuthProtocol("pap");
/* 153:153 */      this.password = decodePapPassword(userPassword.getAttributeData(), RadiusUtil.getUtf8Bytes(sharedSecret));
/* 154:    */      
/* 155:155 */      userPassword.setAttributeData(RadiusUtil.getUtf8Bytes(this.password));
/* 156:156 */    } else if ((chapPassword != null) && (chapChallenge != null)) {
/* 157:157 */      setAuthProtocol("chap");
/* 158:158 */      this.chapPassword = chapPassword.getAttributeData();
/* 159:159 */      this.chapChallenge = chapChallenge.getAttributeData();
/* 160:    */    } else {
/* 161:161 */      throw new RadiusException("Access-Request: User-Password or CHAP-Password/CHAP-Challenge missing");
/* 162:    */    }
/* 163:    */  }
/* 164:    */  
/* 167:    */  protected void encodeRequestAttributes(String sharedSecret)
/* 168:    */  {
/* 169:169 */    if ((this.password == null) || (this.password.length() == 0)) {
/* 170:170 */      return;
/* 171:    */    }
/* 172:    */    
/* 174:174 */    if (getAuthProtocol().equals("pap")) {
/* 175:175 */      byte[] pass = encodePapPassword(RadiusUtil.getUtf8Bytes(this.password), RadiusUtil.getUtf8Bytes(sharedSecret));
/* 176:176 */      removeAttributes(2);
/* 177:177 */      addAttribute(new RadiusAttribute(2, pass));
/* 178:178 */    } else if (getAuthProtocol().equals("chap")) {
/* 179:179 */      byte[] challenge = createChapChallenge();
/* 180:180 */      byte[] pass = encodeChapPassword(this.password, challenge);
/* 181:181 */      removeAttributes(3);
/* 182:182 */      removeAttributes(60);
/* 183:183 */      addAttribute(new RadiusAttribute(3, pass));
/* 184:184 */      addAttribute(new RadiusAttribute(60, challenge));
/* 185:    */    }
/* 186:    */  }
/* 187:    */  
/* 197:    */  private byte[] encodePapPassword(byte[] userPass, byte[] sharedSecret)
/* 198:    */  {
/* 199:199 */    byte[] userPassBytes = (byte[])null;
/* 200:200 */    if (userPass.length > 128) {
/* 201:201 */      userPassBytes = new byte[''];
/* 202:202 */      System.arraycopy(userPass, 0, userPassBytes, 0, 128);
/* 203:    */    } else {
/* 204:204 */      userPassBytes = userPass;
/* 205:    */    }
/* 206:    */    
/* 208:208 */    byte[] encryptedPass = (byte[])null;
/* 209:209 */    if (userPassBytes.length < 128) {
/* 210:210 */      if (userPassBytes.length % 16 == 0)
/* 211:    */      {
/* 212:212 */        encryptedPass = new byte[userPassBytes.length];
/* 213:    */      }
/* 214:    */      else {
/* 215:215 */        encryptedPass = new byte[userPassBytes.length / 16 * 16 + 16];
/* 216:    */      }
/* 217:    */    }
/* 218:    */    else {
/* 219:219 */      encryptedPass = new byte[''];
/* 220:    */    }
/* 221:    */    
/* 223:223 */    System.arraycopy(userPassBytes, 0, encryptedPass, 0, userPassBytes.length);
/* 224:224 */    for (int i = userPassBytes.length; i < encryptedPass.length; i++) {
/* 225:225 */      encryptedPass[i] = 0;
/* 226:    */    }
/* 227:    */    
/* 229:229 */    MessageDigest md5 = getMd5Digest();
/* 230:230 */    byte[] lastBlock = new byte[16];
/* 231:    */    
/* 232:232 */    for (int i = 0; i < encryptedPass.length; i += 16) {
/* 233:233 */      md5.reset();
/* 234:234 */      md5.update(sharedSecret);
/* 235:235 */      md5.update(i == 0 ? getAuthenticator() : lastBlock);
/* 236:236 */      byte[] bn = md5.digest();
/* 237:    */      
/* 238:238 */      System.arraycopy(encryptedPass, i, lastBlock, 0, 16);
/* 239:    */      
/* 241:241 */      for (int j = 0; j < 16; j++) {
/* 242:242 */        encryptedPass[(i + j)] = ((byte)(bn[j] ^ encryptedPass[(i + j)]));
/* 243:    */      }
/* 244:    */    }
/* 245:245 */    return encryptedPass;
/* 246:    */  }
/* 247:    */  
/* 253:    */  private String decodePapPassword(byte[] encryptedPass, byte[] sharedSecret)
/* 254:    */    throws RadiusException
/* 255:    */  {
/* 256:256 */    if ((encryptedPass == null) || (encryptedPass.length < 16))
/* 257:    */    {
/* 258:258 */      logger.warn("invalid Radius packet: User-Password attribute with malformed PAP password, length = " + 
/* 259:259 */        encryptedPass.length + ", but length must be greater than 15");
/* 260:260 */      throw new RadiusException("malformed User-Password attribute");
/* 261:    */    }
/* 262:    */    
/* 263:263 */    MessageDigest md5 = getMd5Digest();
/* 264:264 */    byte[] lastBlock = new byte[16];
/* 265:    */    
/* 266:266 */    for (int i = 0; i < encryptedPass.length; i += 16) {
/* 267:267 */      md5.reset();
/* 268:268 */      md5.update(sharedSecret);
/* 269:269 */      md5.update(i == 0 ? getAuthenticator() : lastBlock);
/* 270:270 */      byte[] bn = md5.digest();
/* 271:    */      
/* 272:272 */      System.arraycopy(encryptedPass, i, lastBlock, 0, 16);
/* 273:    */      
/* 275:275 */      for (int j = 0; j < 16; j++) {
/* 276:276 */        encryptedPass[(i + j)] = ((byte)(bn[j] ^ encryptedPass[(i + j)]));
/* 277:    */      }
/* 278:    */    }
/* 279:    */    
/* 280:280 */    int len = encryptedPass.length;
/* 281:281 */    while ((len > 0) && (encryptedPass[(len - 1)] == 0))
/* 282:282 */      len--;
/* 283:283 */    byte[] passtrunc = new byte[len];
/* 284:284 */    System.arraycopy(encryptedPass, 0, passtrunc, 0, len);
/* 285:    */    
/* 287:287 */    return RadiusUtil.getStringFromUtf8(passtrunc);
/* 288:    */  }
/* 289:    */  
/* 293:    */  private byte[] createChapChallenge()
/* 294:    */  {
/* 295:295 */    byte[] challenge = new byte[16];
/* 296:296 */    random.nextBytes(challenge);
/* 297:297 */    return challenge;
/* 298:    */  }
/* 299:    */  
/* 306:    */  private byte[] encodeChapPassword(String plaintext, byte[] chapChallenge)
/* 307:    */  {
/* 308:308 */    byte chapIdentifier = (byte)random.nextInt(256);
/* 309:309 */    byte[] chapPassword = new byte[17];
/* 310:310 */    chapPassword[0] = chapIdentifier;
/* 311:    */    
/* 312:312 */    MessageDigest md5 = getMd5Digest();
/* 313:313 */    md5.reset();
/* 314:314 */    md5.update(chapIdentifier);
/* 315:315 */    md5.update(RadiusUtil.getUtf8Bytes(plaintext));
/* 316:316 */    byte[] chapHash = md5.digest(chapChallenge);
/* 317:    */    
/* 318:318 */    System.arraycopy(chapHash, 0, chapPassword, 1, 16);
/* 319:319 */    return chapPassword;
/* 320:    */  }
/* 321:    */  
/* 325:    */  private boolean verifyChapPassword(String plaintext)
/* 326:    */    throws RadiusException
/* 327:    */  {
/* 328:328 */    if ((plaintext == null) || (plaintext.length() == 0))
/* 329:329 */      throw new IllegalArgumentException("plaintext must not be empty");
/* 330:330 */    if ((this.chapChallenge == null) || (this.chapChallenge.length != 16))
/* 331:331 */      throw new RadiusException("CHAP challenge must be 16 bytes");
/* 332:332 */    if ((this.chapPassword == null) || (this.chapPassword.length != 17)) {
/* 333:333 */      throw new RadiusException("CHAP password must be 17 bytes");
/* 334:    */    }
/* 335:335 */    byte chapIdentifier = this.chapPassword[0];
/* 336:336 */    MessageDigest md5 = getMd5Digest();
/* 337:337 */    md5.reset();
/* 338:338 */    md5.update(chapIdentifier);
/* 339:339 */    md5.update(RadiusUtil.getUtf8Bytes(plaintext));
/* 340:340 */    byte[] chapHash = md5.digest(this.chapChallenge);
/* 341:    */    
/* 345:345 */    for (int i = 0; i < 16; i++)
/* 346:346 */      if (chapHash[i] != this.chapPassword[(i + 1)])
/* 347:347 */        return false;
/* 348:348 */    return true;
/* 349:    */  }
/* 350:    */  
/* 360:360 */  private String authProtocol = "pap";
/* 361:    */  
/* 365:    */  private byte[] chapPassword;
/* 366:    */  
/* 370:    */  private byte[] chapChallenge;
/* 371:    */  
/* 375:375 */  private static SecureRandom random = new SecureRandom();
/* 376:    */  
/* 380:    */  private static final int USER_NAME = 1;
/* 381:    */  
/* 385:    */  private static final int USER_PASSWORD = 2;
/* 386:    */  
/* 390:    */  private static final int CHAP_PASSWORD = 3;
/* 391:    */  
/* 395:    */  private static final int CHAP_CHALLENGE = 60;
/* 396:    */  
/* 400:400 */  private static Log logger = LogFactory.getLog(AccessRequest.class);
/* 401:    */}


/* Location:           D:\cache\windows\Desktop\radius-server-1.0\
 * Qualified Name:     com.radius.server.packet.AccessRequest
 * JD-Core Version:    0.7.0-SNAPSHOT-20130630
 */