/*  1:   */package com.radius.server.util;
/*  2:   */
/*  8:   */public class RadiusException
/*  9:   */  extends Exception
/* 10:   */{
/* 11:   */  private static final long serialVersionUID = 2201204523946051388L;
/* 12:   */  
/* 18:   */  public RadiusException(String message)
/* 19:   */  {
/* 20:20 */    super(message);
/* 21:   */  }
/* 22:   */}


/* Location:           D:\cache\windows\Desktop\radius-server-1.0\
 * Qualified Name:     com.radius.server.util.RadiusException
 * JD-Core Version:    0.7.0-SNAPSHOT-20130630
 */