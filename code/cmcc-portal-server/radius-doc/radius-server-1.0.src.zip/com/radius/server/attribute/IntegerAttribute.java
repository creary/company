/*   1:    */package com.radius.server.attribute;
/*   2:    */
/*   3:    */import com.radius.server.dictionary.AttributeType;
/*   4:    */import com.radius.server.util.RadiusException;
/*   5:    */
/*  24:    */public class IntegerAttribute
/*  25:    */  extends RadiusAttribute
/*  26:    */{
/*  27:    */  public IntegerAttribute() {}
/*  28:    */  
/*  29:    */  public IntegerAttribute(int type, int value)
/*  30:    */  {
/*  31: 31 */    setAttributeType(type);
/*  32: 32 */    setAttributeValue(value);
/*  33:    */  }
/*  34:    */  
/*  38:    */  public int getAttributeValueInt()
/*  39:    */  {
/*  40: 40 */    byte[] data = getAttributeData();
/*  41: 41 */    return (data[0] & 0xFF) << 24 | (data[1] & 0xFF) << 16 | 
/*  42: 42 */      (data[2] & 0xFF) << 8 | data[3] & 0xFF;
/*  43:    */  }
/*  44:    */  
/*  49:    */  public String getAttributeValue()
/*  50:    */  {
/*  51: 51 */    int value = getAttributeValueInt();
/*  52: 52 */    AttributeType at = getAttributeTypeObject();
/*  53: 53 */    if (at != null) {
/*  54: 54 */      String name = at.getEnumeration(value);
/*  55: 55 */      if (name != null) {
/*  56: 56 */        return name;
/*  57:    */      }
/*  58:    */    }
/*  59: 59 */    return Integer.toString(value);
/*  60:    */  }
/*  61:    */  
/*  65:    */  public void setAttributeValue(int value)
/*  66:    */  {
/*  67: 67 */    byte[] data = new byte[4];
/*  68: 68 */    data[0] = ((byte)(value >> 24 & 0xFF));
/*  69: 69 */    data[1] = ((byte)(value >> 16 & 0xFF));
/*  70: 70 */    data[2] = ((byte)(value >> 8 & 0xFF));
/*  71: 71 */    data[3] = ((byte)(value & 0xFF));
/*  72: 72 */    setAttributeData(data);
/*  73:    */  }
/*  74:    */  
/*  79:    */  public void setAttributeValue(String value)
/*  80:    */  {
/*  81: 81 */    AttributeType at = getAttributeTypeObject();
/*  82: 82 */    if (at != null) {
/*  83: 83 */      Integer val = at.getEnumeration(value);
/*  84: 84 */      if (val != null) {
/*  85: 85 */        setAttributeValue(val.intValue());
/*  86: 86 */        return;
/*  87:    */      }
/*  88:    */    }
/*  89:    */    
/*  90: 90 */    setAttributeValue(Integer.parseInt(value));
/*  91:    */  }
/*  92:    */  
/*  96:    */  public void readAttribute(byte[] data, int offset, int length)
/*  97:    */    throws RadiusException
/*  98:    */  {
/*  99: 99 */    if (length != 6)
/* 100:100 */      throw new RadiusException("integer attribute: expected 4 bytes data");
/* 101:101 */    super.readAttribute(data, offset, length);
/* 102:    */  }
/* 103:    */}


/* Location:           D:\cache\windows\Desktop\radius-server-1.0\
 * Qualified Name:     com.radius.server.attribute.IntegerAttribute
 * JD-Core Version:    0.7.0-SNAPSHOT-20130630
 */