/*  1:   */package com.radius.server.attribute;
/*  2:   */
/*  3:   */import java.io.UnsupportedEncodingException;
/*  4:   */
/* 23:   */public class StringAttribute
/* 24:   */  extends RadiusAttribute
/* 25:   */{
/* 26:   */  public StringAttribute() {}
/* 27:   */  
/* 28:   */  public StringAttribute(int type, String value)
/* 29:   */  {
/* 30:30 */    setAttributeType(type);
/* 31:31 */    setAttributeValue(value);
/* 32:   */  }
/* 33:   */  
/* 36:   */  public String getAttributeValue()
/* 37:   */  {
/* 38:   */    try
/* 39:   */    {
/* 40:40 */      return new String(getAttributeData(), "UTF-8");
/* 41:   */    } catch (UnsupportedEncodingException uee) {}
/* 42:42 */    return new String(getAttributeData());
/* 43:   */  }
/* 44:   */  
/* 49:   */  public void setAttributeValue(String value)
/* 50:   */  {
/* 51:51 */    if (value == null)
/* 52:52 */      throw new NullPointerException("string value not set");
/* 53:   */    try {
/* 54:54 */      setAttributeData(value.getBytes("UTF-8"));
/* 55:   */    } catch (UnsupportedEncodingException uee) {
/* 56:56 */      setAttributeData(value.getBytes());
/* 57:   */    }
/* 58:   */  }
/* 59:   */}


/* Location:           D:\cache\windows\Desktop\radius-server-1.0\
 * Qualified Name:     com.radius.server.attribute.StringAttribute
 * JD-Core Version:    0.7.0-SNAPSHOT-20130630
 */