/*  1:   */package com.radius.server.dictionary;
/*  2:   */
/*  3:   */import java.io.File;
/*  4:   */import java.io.IOException;
/*  5:   */import java.io.InputStream;
/*  6:   */import java.net.URL;
/*  7:   */
/* 21:   */public class DefaultDictionary
/* 22:   */  extends MemoryDictionary
/* 23:   */{
/* 24:   */  private static final String DICTIONARY_RESOURCE = "com/jwsoft/wlan/cmccserver/radius/dictionary/file/default_dictionary";
/* 25:   */  
/* 26:   */  public static Dictionary getDefaultDictionary()
/* 27:   */  {
/* 28:28 */    return instance;
/* 29:   */  }
/* 30:   */  
/* 40:40 */  private static DefaultDictionary instance = null;
/* 41:   */  
/* 44:   */  static
/* 45:   */  {
/* 46:   */    try
/* 47:   */    {
/* 48:48 */      instance = new DefaultDictionary();
/* 49:49 */      String filepath = DefaultDictionary.class.getClassLoader().getResource("com/jwsoft/wlan/cmccserver/radius/dictionary/file/default_dictionary").getFile();
/* 50:50 */      InputStream source = DefaultDictionary.class.getClassLoader().getResourceAsStream("com/jwsoft/wlan/cmccserver/radius/dictionary/file/default_dictionary");
/* 51:51 */      DictionaryParser.parseDictionary(new File(filepath).getParent(), source, instance);
/* 52:   */    } catch (IOException e) {
/* 53:53 */      throw new RuntimeException("default dictionary unavailable", e);
/* 54:   */    }
/* 55:   */  }
/* 56:   */  
/* 57:   */  public static void main(String[] args) {
/* 58:58 */    getDefaultDictionary();
/* 59:   */  }
/* 60:   */}


/* Location:           D:\cache\windows\Desktop\radius-server-1.0\
 * Qualified Name:     com.radius.server.dictionary.DefaultDictionary
 * JD-Core Version:    0.7.0-SNAPSHOT-20130630
 */