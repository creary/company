/*  1:   */package com.radius.server.test;
/*  2:   */
/*  3:   */import com.radius.server.packet.AccessRequest;
/*  4:   */import com.radius.server.packet.RadiusPacket;
/*  5:   */import com.radius.server.util.RadiusException;
/*  6:   */import com.radius.server.util.RadiusServer;
/*  7:   */import java.io.IOException;
/*  8:   */import java.io.PrintStream;
/*  9:   */import java.net.InetAddress;
/* 10:   */import java.net.InetSocketAddress;
/* 11:   */
/* 22:   */public class TestServer
/* 23:   */{
/* 24:   */  public static void main(String[] args)
/* 25:   */    throws IOException, Exception
/* 26:   */  {
/* 27:27 */    args = new String[] { "1812", "1813" };
/* 28:   */    
/* 29:29 */    RadiusServer server = new RadiusServer()
/* 30:   */    {
/* 31:   */      public String getSharedSecret(InetSocketAddress client) {
/* 32:32 */        if (client.getAddress().getHostAddress().equals("127.0.0.1")) {
/* 33:33 */          return "testing123";
/* 34:   */        }
/* 35:35 */        return null;
/* 36:   */      }
/* 37:   */      
/* 38:   */      public String getUserPassword(String userName)
/* 39:   */      {
/* 40:40 */        if (userName.equals("mw")) {
/* 41:41 */          return "test";
/* 42:   */        }
/* 43:43 */        return null;
/* 44:   */      }
/* 45:   */      
/* 46:   */      public RadiusPacket accessRequestReceived(AccessRequest accessRequest, InetSocketAddress client)
/* 47:   */        throws RadiusException
/* 48:   */      {
/* 49:49 */        System.out.println("Received Access-Request:\n" + accessRequest);
/* 50:50 */        RadiusPacket packet = super.accessRequestReceived(accessRequest, client);
/* 51:51 */        if (packet == null)
/* 52:52 */          System.out.println("Ignore packet.");
/* 53:53 */        if (packet.getPacketType() == 2) {
/* 54:54 */          packet.addAttribute("Reply-Message", "Welcome " + accessRequest.getUserName() + "!");
/* 55:   */        }
/* 56:   */        else
/* 57:57 */          System.out.println("Answer:\n" + packet);
/* 58:58 */        return packet;
/* 59:   */      }
/* 60:   */    };
/* 61:61 */    if (args.length >= 1)
/* 62:62 */      server.setAuthPort(Integer.parseInt(args[0]));
/* 63:63 */    if (args.length >= 2) {
/* 64:64 */      server.setAcctPort(Integer.parseInt(args[1]));
/* 65:   */    }
/* 66:66 */    server.start(true, true);
/* 67:   */    
/* 68:68 */    System.out.println("Server started.");
/* 69:   */    
/* 70:70 */    Thread.sleep(1800000L);
/* 71:71 */    System.out.println("Stop server");
/* 72:72 */    server.stop();
/* 73:   */  }
/* 74:   */}


/* Location:           D:\cache\windows\Desktop\radius-server-1.0\
 * Qualified Name:     com.radius.server.test.TestServer
 * JD-Core Version:    0.7.0-SNAPSHOT-20130630
 */