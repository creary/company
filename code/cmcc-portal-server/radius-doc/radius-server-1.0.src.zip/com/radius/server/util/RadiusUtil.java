/*  1:   */package com.radius.server.util;
/*  2:   */
/*  3:   */import java.io.UnsupportedEncodingException;
/*  4:   */
/* 18:   */public class RadiusUtil
/* 19:   */{
/* 20:   */  public static byte[] getUtf8Bytes(String str)
/* 21:   */  {
/* 22:   */    try
/* 23:   */    {
/* 24:24 */      return str.getBytes("UTF-8");
/* 25:   */    } catch (UnsupportedEncodingException uee) {}
/* 26:26 */    return str.getBytes();
/* 27:   */  }
/* 28:   */  
/* 34:   */  public static String getStringFromUtf8(byte[] utf8)
/* 35:   */  {
/* 36:   */    try
/* 37:   */    {
/* 38:38 */      return new String(utf8, "UTF-8");
/* 39:   */    } catch (UnsupportedEncodingException uee) {}
/* 40:40 */    return new String(utf8);
/* 41:   */  }
/* 42:   */  
/* 49:   */  public static String getHexString(byte[] data)
/* 50:   */  {
/* 51:51 */    StringBuffer hex = new StringBuffer("0x");
/* 52:52 */    if (data != null)
/* 53:53 */      for (int i = 0; i < data.length; i++) {
/* 54:54 */        String digit = Integer.toString(data[i] & 0xFF, 16);
/* 55:55 */        if (digit.length() < 2)
/* 56:56 */          hex.append('0');
/* 57:57 */        hex.append(digit);
/* 58:   */      }
/* 59:59 */    return hex.toString();
/* 60:   */  }
/* 61:   */}


/* Location:           D:\cache\windows\Desktop\radius-server-1.0\
 * Qualified Name:     com.radius.server.util.RadiusUtil
 * JD-Core Version:    0.7.0-SNAPSHOT-20130630
 */