/*  1:   */package com.radius.server.util;
/*  2:   */
/*  3:   */import java.net.InetSocketAddress;
/*  4:   */
/* 17:   */public class RadiusEndpoint
/* 18:   */{
/* 19:   */  private InetSocketAddress endpointAddress;
/* 20:   */  private String sharedSecret;
/* 21:   */  
/* 22:   */  public RadiusEndpoint(InetSocketAddress remoteAddress, String sharedSecret)
/* 23:   */  {
/* 24:24 */    this.endpointAddress = remoteAddress;
/* 25:25 */    this.sharedSecret = sharedSecret;
/* 26:   */  }
/* 27:   */  
/* 31:   */  public InetSocketAddress getEndpointAddress()
/* 32:   */  {
/* 33:33 */    return this.endpointAddress;
/* 34:   */  }
/* 35:   */  
/* 39:   */  public String getSharedSecret()
/* 40:   */  {
/* 41:41 */    return this.sharedSecret;
/* 42:   */  }
/* 43:   */}


/* Location:           D:\cache\windows\Desktop\radius-server-1.0\
 * Qualified Name:     com.radius.server.util.RadiusEndpoint
 * JD-Core Version:    0.7.0-SNAPSHOT-20130630
 */