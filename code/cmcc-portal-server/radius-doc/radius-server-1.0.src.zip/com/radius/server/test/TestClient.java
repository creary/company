/*  1:   */package com.radius.server.test;
/*  2:   */
/*  3:   */import com.radius.server.packet.AccessRequest;
/*  4:   */import com.radius.server.packet.AccountingRequest;
/*  5:   */import com.radius.server.packet.RadiusPacket;
/*  6:   */import com.radius.server.util.RadiusClient;
/*  7:   */import java.io.PrintStream;
/*  8:   */
/* 23:   */public class TestClient
/* 24:   */{
/* 25:   */  public static void main(String[] args)
/* 26:   */    throws Exception
/* 27:   */  {
/* 28:28 */    args = new String[] { "127.0.0.1", "test123", "mw", "test" };
/* 29:   */    
/* 30:30 */    if (args.length != 4) {
/* 31:31 */      System.out.println("Usage: TestClient hostName sharedSecret userName password");
/* 32:32 */      System.exit(1);
/* 33:   */    }
/* 34:   */    
/* 35:35 */    String host = args[0];
/* 36:36 */    String shared = args[1];
/* 37:37 */    String user = args[2];
/* 38:38 */    String pass = args[3];
/* 39:   */    
/* 40:40 */    RadiusClient rc = new RadiusClient(host, shared);
/* 41:   */    
/* 43:43 */    AccessRequest ar = new AccessRequest(user, pass);
/* 44:44 */    ar.setAuthProtocol("pap");
/* 45:45 */    ar.addAttribute("NAS-Identifier", "this.is.my.nas-identifier.de");
/* 46:46 */    ar.addAttribute("NAS-IP-Address", "192.168.0.100");
/* 47:47 */    ar.addAttribute("Service-Type", "Login-User");
/* 48:48 */    ar.addAttribute("WISPr-Redirection-URL", "http://www.sourceforge.net/");
/* 49:49 */    ar.addAttribute("WISPr-Location-ID", "net.sourceforge.ap1");
/* 50:   */    
/* 51:51 */    System.out.println("Packet before it is sent\n" + ar + "\n");
/* 52:52 */    RadiusPacket response = rc.authenticate(ar);
/* 53:53 */    System.out.println("Packet after it was sent\n" + ar + "\n");
/* 54:54 */    System.out.println("Response\n" + response + "\n");
/* 55:   */    
/* 57:57 */    AccountingRequest acc = new AccountingRequest("mw", 1);
/* 58:58 */    acc.addAttribute("Acct-Session-Id", "1234567890");
/* 59:59 */    acc.addAttribute("NAS-Identifier", "this.is.my.nas-identifier.de");
/* 60:60 */    acc.addAttribute("NAS-Port", "0");
/* 61:   */    
/* 62:62 */    System.out.println(acc + "\n");
/* 63:63 */    response = rc.account(acc);
/* 64:64 */    System.out.println("Response: " + response);
/* 65:   */    
/* 66:66 */    rc.close();
/* 67:   */  }
/* 68:   */}


/* Location:           D:\cache\windows\Desktop\radius-server-1.0\
 * Qualified Name:     com.radius.server.test.TestClient
 * JD-Core Version:    0.7.0-SNAPSHOT-20130630
 */