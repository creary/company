/*   1:    */package com.radius.server.attribute;
/*   2:    */
/*   3:    */import com.radius.server.util.RadiusException;
/*   4:    */import java.util.StringTokenizer;
/*   5:    */
/*  24:    */public class IpAttribute
/*  25:    */  extends RadiusAttribute
/*  26:    */{
/*  27:    */  public IpAttribute() {}
/*  28:    */  
/*  29:    */  public IpAttribute(int type, String value)
/*  30:    */  {
/*  31: 31 */    setAttributeType(type);
/*  32: 32 */    setAttributeValue(value);
/*  33:    */  }
/*  34:    */  
/*  39:    */  public IpAttribute(int type, long ipNum)
/*  40:    */  {
/*  41: 41 */    setAttributeType(type);
/*  42: 42 */    setIpAsLong(ipNum);
/*  43:    */  }
/*  44:    */  
/*  49:    */  public String getAttributeValue()
/*  50:    */  {
/*  51: 51 */    StringBuffer ip = new StringBuffer();
/*  52: 52 */    byte[] data = getAttributeData();
/*  53: 53 */    if ((data == null) || (data.length != 4)) {
/*  54: 54 */      throw new RuntimeException("ip attribute: expected 4 bytes attribute data");
/*  55:    */    }
/*  56: 56 */    ip.append(data[0] & 0xFF);
/*  57: 57 */    ip.append(".");
/*  58: 58 */    ip.append(data[1] & 0xFF);
/*  59: 59 */    ip.append(".");
/*  60: 60 */    ip.append(data[2] & 0xFF);
/*  61: 61 */    ip.append(".");
/*  62: 62 */    ip.append(data[3] & 0xFF);
/*  63:    */    
/*  64: 64 */    return ip.toString();
/*  65:    */  }
/*  66:    */  
/*  73:    */  public void setAttributeValue(String value)
/*  74:    */  {
/*  75: 75 */    if ((value == null) || (value.length() < 7) || (value.length() > 15)) {
/*  76: 76 */      throw new IllegalArgumentException("bad IP number");
/*  77:    */    }
/*  78: 78 */    StringTokenizer tok = new StringTokenizer(value, ".");
/*  79: 79 */    if (tok.countTokens() != 4) {
/*  80: 80 */      throw new IllegalArgumentException("bad IP number: 4 numbers required");
/*  81:    */    }
/*  82: 82 */    byte[] data = new byte[4];
/*  83: 83 */    for (int i = 0; i < 4; i++) {
/*  84: 84 */      int num = Integer.parseInt(tok.nextToken());
/*  85: 85 */      if ((num < 0) || (num > 255))
/*  86: 86 */        throw new IllegalArgumentException("bad IP number: num out of bounds");
/*  87: 87 */      data[i] = ((byte)num);
/*  88:    */    }
/*  89:    */    
/*  90: 90 */    setAttributeData(data);
/*  91:    */  }
/*  92:    */  
/*  97:    */  public long getIpAsLong()
/*  98:    */  {
/*  99: 99 */    byte[] data = getAttributeData();
/* 100:100 */    if ((data == null) || (data.length != 4))
/* 101:101 */      throw new RuntimeException("expected 4 bytes attribute data");
/* 102:102 */    return (data[0] & 0xFF) << 24 | (data[1] & 0xFF) << 16 | 
/* 103:103 */      (data[2] & 0xFF) << 8 | data[3] & 0xFF;
/* 104:    */  }
/* 105:    */  
/* 110:    */  public void setIpAsLong(long ip)
/* 111:    */  {
/* 112:112 */    byte[] data = new byte[4];
/* 113:113 */    data[0] = ((byte)(int)(ip >> 24 & 0xFF));
/* 114:114 */    data[1] = ((byte)(int)(ip >> 16 & 0xFF));
/* 115:115 */    data[2] = ((byte)(int)(ip >> 8 & 0xFF));
/* 116:116 */    data[3] = ((byte)(int)(ip & 0xFF));
/* 117:117 */    setAttributeData(data);
/* 118:    */  }
/* 119:    */  
/* 123:    */  public void readAttribute(byte[] data, int offset, int length)
/* 124:    */    throws RadiusException
/* 125:    */  {
/* 126:126 */    if (length != 6)
/* 127:127 */      throw new RadiusException("IP attribute: expected 4 bytes data");
/* 128:128 */    super.readAttribute(data, offset, length);
/* 129:    */  }
/* 130:    */}


/* Location:           D:\cache\windows\Desktop\radius-server-1.0\
 * Qualified Name:     com.radius.server.attribute.IpAttribute
 * JD-Core Version:    0.7.0-SNAPSHOT-20130630
 */